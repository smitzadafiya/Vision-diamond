﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;

public partial class WebForms_AdminGetSalesInvoice : System.Web.UI.Page
{
    SqlConnection conn;
    String InvoiceNo;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);

        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }

            InvoiceNo = Request.QueryString["InvoiceNo"];

            if (InvoiceNo == null)
            {
                Response.Redirect("AdminSalesInvoice.aspx");
            }

            try
            {
                lbl_InvoiceNo.Text = InvoiceNo;
                conn.Open();
                String q = "select bs.CompanyName,bs.ContactNo,bs.PanNo,bs.GSTIN,bs.Address,bs.Email,c.CityName,s.StateName,co.CountryName from tblBuyerSeller bs,tblCity c,tblState s, tblCountry co,tblSales sell where sell.InvoiceNo=@InvoiceNo and bs.BuyerSellerID=sell.BuyerSellerID and c.CityID = bs.CityID and s.StateID = c.StateID and co.CountryID = s.CountryID";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@InvoiceNo", InvoiceNo);
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                lbl_CompanyName.Text = reader["CompanyName"].ToString();
                lbl_MobileNo.Text = reader["ContactNo"].ToString();
                lbl_PANNO.Text = reader["PanNo"].ToString();
                lbl_GSTIN.Text = reader["GSTIN"].ToString();
                lbl_EmailAddress.Text = reader["Email"].ToString();
                lbl_Address.Text = reader["Address"].ToString();
                lbl_City.Text = reader["CityName"].ToString();
                lbl_State.Text = reader["StateName"].ToString();
                lbl_Country.Text = reader["CountryName"].ToString();
                conn.Close();

                //String Mode="", ModeID=""; ;

                conn.Open();
                q = "select si.Mode,sell.SellingDate,sell.DayTerm,sell.Weight,sell.Rate,sell.TransportationMode,sell.DateOfSupply,sell.PlaceOfSupply,sell.ModeID from tblSales sell,tblSalesInvoice si where sell.InvoiceNo=@InvoiceNo and si.InvoiceNo=sell.InvoiceNo";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@InvoiceNo", InvoiceNo);
                reader = cmd.ExecuteReader();
                reader.Read();
                if (reader["Mode"].ToString().Equals("1"))
                {
                    lbl_DiamondType.Text = "Rough";
                    //Mode = "1";
                }
                else if (reader["Mode"].ToString().Equals("2") || reader["Mode"].ToString().Equals("3"))
                {
                    lbl_DiamondType.Text = "Polished";

                }
                else if (reader["Mode"].ToString().Equals("4"))
                {
                    lbl_DiamondType.Text = "Rejection";
                    //Mode = "4";
                }
                lbl_InvoiceDate.Text = reader["SellingDate"].ToString();
                lbl_DayTerm.Text = reader["DayTerm"].ToString();
                lbl_Weight.Text = reader["Weight"].ToString();
                lbl_Rate.Text = reader["Rate"].ToString();
                lbl_TransportationMode.Text = reader["TransportationMode"].ToString();
                lbl_DateOfSupply.Text = reader["DateOfSupply"].ToString();
                lbl_PlaceOfSupply.Text = reader["PlaceOfSupply"].ToString();
                //ModeID = reader["ModeID"].ToString();
                conn.Close();

                lbl_TotalAmount.Text = (Convert.ToDouble(lbl_Weight.Text) * Convert.ToDouble(lbl_Rate.Text)).ToString();
                lbl_CGST.Text = ((Convert.ToDouble(lbl_TotalAmount.Text) * 18) / 100).ToString();
                lbl_SGST.Text = ((Convert.ToDouble(lbl_TotalAmount.Text) * 12) / 100).ToString();
                lbl_IGST.Text = ((Convert.ToDouble(lbl_TotalAmount.Text) * 18) / 100).ToString();

                lbl_TotalPayableAmount.Text = (Convert.ToDouble(lbl_TotalAmount.Text) + Convert.ToDouble(lbl_CGST.Text) + Convert.ToDouble(lbl_SGST.Text) + Convert.ToDouble(lbl_IGST.Text)).ToString() + " Rs.";

                /*if (Mode.Equals("1") || Mode.Equals("2"))
                {
                    conn.Open();
                    q = "select Weight,Amount from tblPurchaseDetails where PurchaseID=@ModeID";
                    cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@ModeID", ModeID);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_ProfitLoss.Text = (Convert.ToDouble(lbl_TotalPayableAmount.Text) - (Convert.ToDouble(lbl_Weight.Text) * Convert.ToDouble(reader["Amount"].ToString()))).ToString();
                    conn.Close();
                }
                else if (Mode.Equals("3"))
                {
                    conn.Open();
                    q = "select Weight,Amount from tblPurchaseDetails where PurchaseID=@ModeID";
                    cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@ModeID", ModeID);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_ProfitLoss.Text = (Convert.ToDouble(lbl_TotalPayableAmount.Text) - (Convert.ToDouble(reader["Weight"].ToString()) * Convert.ToDouble(reader["Amount"].ToString()))).ToString();
                    conn.Close();

                    conn.Open();
                    q = "select AllocationID from tblPurchaseAllocation where PurchaseID=@ModeID";
                    cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@ModeID", ModeID);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    String AID = reader["AllocationID"].ToString();
                    conn.Close();

                    conn.Open();
                    q = "select Weight,Rate from tblCutting where AllocationID=@AID";
                    cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@AID", AID);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_ProfitLoss.Text = (Convert.ToDouble(lbl_ProfitLoss.Text) - (Convert.ToDouble(reader["Weight"].ToString()) * Convert.ToDouble(reader["Rate"].ToString()))).ToString();
                    conn.Close();

                    conn.Open();
                    q = "select PolishedWeight,Rate from tblPolished where AllocationID=@AID";
                    cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@AID", AID);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_ProfitLoss.Text = (Convert.ToDouble(lbl_ProfitLoss.Text) - (Convert.ToDouble(reader["PolishedWeight"].ToString()) * Convert.ToDouble(reader["Rate"].ToString()))).ToString();
                    conn.Close();
                }
                else if (Mode.Equals("4"))
                {
                    lbl_ProfitLoss.Text = lbl_TotalPayableAmount.Text;
                }

                if (Convert.ToDouble(lbl_ProfitLoss.Text) <= 0)
                {
                    lbl_ProfitLoss.Text = "You Lost " + lbl_ProfitLoss.Text + " Rs.";
                }
                else
                {
                    lbl_ProfitLoss.Text = "You Profit " + lbl_ProfitLoss.Text + " Rs.";
                }*/
            }
            catch (Exception ex)
            {
                Response.Redirect("AdminSalesInvoice.aspx");
            }
        }
    }

    protected void btn_BackClicked(object sender, EventArgs e)
    {
        Response.Redirect("AdminSalesInvoice.aspx");
    }
    protected void btn_downloadClicked(object sender, EventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename='" + lbl_InvoiceDate.Text + "'.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        Panel1.RenderControl(hw);
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();
    }
}