﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.DataVisualization.Charting;

public partial class WebForms_BranchDashboard : System.Web.UI.Page
{
    SqlConnection conn;
    String date, desc, rid;
    String lid, username, password, bid;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            try
            {
                lid = Session["Lid"].ToString();
                username = Session["Username"].ToString();
                password = Session["Password"].ToString();
                bid = Session["BID"].ToString();

                lbl_Bname.Text = username;
                if (lid == null || username == null || password == null || bid == null)
                {
                    Response.Redirect("Login.aspx?message=1");
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("Login.aspx?message=1");
            }

            conn.Open();
            String q = "select a.AllocationID,p.Weight,a.AllocationDate,a.Notes from tblPurchaseAllocation a,tblPurchaseDetails p where a.BranchID=@bid and a.Status=@status and p.PurchaseID=a.PurchaseID and p.Status='0'";
            SqlCommand cmd = new SqlCommand(q,conn);
            cmd.Parameters.AddWithValue("@bid",bid);
            cmd.Parameters.AddWithValue("@status", "1");
            Grid_AcceptDiamond.DataSource = cmd.ExecuteReader();
            Grid_AcceptDiamond.DataBind();
            conn.Close();



            conn.Open();
            string q1 = "select rid,date,description from tblReminder where status='0' and branchid='"+bid+"'";


            SqlCommand cmd2 = new SqlCommand(q1, conn);
            SqlDataReader rd = cmd2.ExecuteReader();
            while (rd.Read())
            {
                rid = rd["rid"].ToString();
                date = rd["date"].ToString();
                desc = rd["description"].ToString();
            }
            conn.Close();
            Label1.Text = date + " " + desc;


        }
    }

    protected void AcceptDiamond(object sender, EventArgs e)
    {
        GridViewRow gr = Grid_AcceptDiamond.SelectedRow;
        String AID = gr.Cells[1].Text;
        try {
            conn.Open();
            String q = "update tblPurchaseAllocation set Status='0' where AllocationID=@AID";
            SqlCommand cmd = new SqlCommand(q,conn);
            cmd.Parameters.AddWithValue("@AID",AID);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Redirect("BranchDashboard.aspx");
            }
            else
            {
                Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
            }
            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        conn.Open();
        string q3 = "update tblReminder set status='1' where rid='" + rid + "'";
        SqlCommand cmd = new SqlCommand(q3, conn);
        cmd.ExecuteNonQuery();
        conn.Close();
    }
}