﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_BranchAllocation : System.Web.UI.Page
{
    String pid,op,aid;
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }

            pid = Request.QueryString["pid"];
            if (pid == null)
            {
                Response.Redirect("PurchaseDetails.aspx");
            }
            else
            {
                if (!Page.IsPostBack)
                {
                    String q1 = "select BranchID,BranchName from tblBranch where status='0'";
                    conn.Open();
                    SqlCommand cmd1 = new SqlCommand(q1, conn);
                    drop_Branch.DataValueField = "BranchID";
                    drop_Branch.DataTextField = "BranchName";
                    drop_Branch.DataSource = cmd1.ExecuteReader();
                    drop_Branch.DataBind();
                    conn.Close();
                }

                conn.Open();
                String q = "select InvoiceNo,PurchaseDate,Weight,Amount,DiamondStatus from tblPurchaseDetails where PurchaseID=@pid";
                SqlCommand cmd = new SqlCommand(q,conn);
                cmd.Parameters.AddWithValue("@pid",pid);
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                lbl_InvoiceNo.Text = reader["InvoiceNo"].ToString();
                lbl_PurchaseDate.Text = reader["PurchaseDate"].ToString();
                lbl_Weight.Text = reader["Weight"].ToString();
                lbl_Amount.Text = reader["Amount"].ToString();
                String dStatus = reader["DiamondStatus"].ToString();
                conn.Close();
                if (dStatus.Equals("1"))
                {
                    btn_Allocation.Text = "Allocate";
                    op = "Allocation";
                }
                else if (dStatus.Equals("2"))
                {
                    if(!Page.IsPostBack)
                    {
                        conn.Open();
                        q = "select AllocationID,BranchID,Notes from tblPurchaseAllocation where PurchaseID=@pid";
                        cmd = new SqlCommand(q, conn);
                        cmd.Parameters.AddWithValue("@pid", pid);
                        reader = cmd.ExecuteReader();
                        reader.Read();
                        drop_Branch.SelectedValue = reader["BranchID"].ToString();
                        aid = reader["AllocationID"].ToString();
                        txt_Notes.Value = reader["Notes"].ToString();
                        conn.Close();
                        drop_BranchChanged(sender, e);
                    }
                    btn_Allocation.Text = "Update Allocation";
                    op = "UpdateAllocation";
                }
                else
                {
                    Response.Write("<script>alert('Can't Update Allocation Because Cutting is Done !!')</script>");
                    Response.Redirect("PurchaseDetails.aspx");
                }
            }
            drop_BranchChanged(sender, e);
        }
    }

    protected void btn_AllocationClicked(object sender, EventArgs e)
    {
        if (op.Equals("Allocation"))
        {
            conn.Open();
            String q = "insert into tblPurchaseAllocation (BranchID,PurchaseID,AllocationDate,Notes,Status) values (@bid,@pid,GETDATE(),@notes,@status)";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@bid", drop_Branch.SelectedValue);
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@notes", txt_Notes.Value);
            cmd.Parameters.AddWithValue("@status","1");
            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i == 1)
            {
                conn.Open();
                q = "update tblPurchaseDetails set DiamondStatus='2' where PurchaseID=@pid";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@pid", pid);
                i = cmd.ExecuteNonQuery();
                conn.Close();
                if (i == 1)
                {
                        Response.Write("<script>alert('Successfully Allocted..')</script>");
                        Server.Transfer("BranchAllocation.aspx?pid=" + pid);
                }
                else
                {
                    Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
            }
        }
        else
        {
            conn.Open();
            String q = "update tblPurchaseAllocation set BranchID=@bid,Notes=@notes where PurchaseID=@pid";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@bid", drop_Branch.SelectedValue);
            cmd.Parameters.AddWithValue("@notes", txt_Notes.Value);
            cmd.Parameters.AddWithValue("@pid", pid);
            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i == 1)
            {
                Response.Write("<script>alert('Successfully Updated..')</script>");
                Server.Transfer("BranchAllocation.aspx?pid=" + pid);
            }
            else
            {
                Response.Write("<script>alert('Somthing Went Wrong..')</script>");
            }
        }
    }
    protected void drop_BranchChanged(object sender, EventArgs e)
    {
        conn.Close();
        conn.Open();
        String q = "select b.BranchName,b.ContactNo,b.Address,m.ManagerName from tblBranch b,tblManager m where b.ManagerID = m.ManagerID and b.BranchID = @bid";
        SqlCommand cmd = new SqlCommand(q,conn);
        cmd.Parameters.AddWithValue("@bid",drop_Branch.SelectedValue);
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        lbl_bname.Text = reader["BranchName"].ToString();
        lbl_ContactNo.Text = reader["ContactNo"].ToString();
        lbl_address.Text = reader["Address"].ToString();
        lbl_managerName.Text = reader["ManagerName"].ToString();
        conn.Close();
    }

    protected void btn_Back_Clicked(object sender, EventArgs e)
    {
        Response.Redirect("PurchaseDetails.aspx");
    }
}