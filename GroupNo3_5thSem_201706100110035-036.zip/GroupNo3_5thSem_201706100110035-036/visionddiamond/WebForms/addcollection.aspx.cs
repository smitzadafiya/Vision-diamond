﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


    public partial class WebForms_addcollection : System.Web.UI.Page
    {
    string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
    SqlConnection cn;
    string a, b;
        protected void Page_Load(object sender, EventArgs e)
        {
        cn = new SqlConnection(connection);
        if (Session.IsNewSession)
            {
                    Server.Transfer("Login.aspx?message=1");
            }
            else
            {
                String username = Session["username"].ToString();
                String password = Session["password"].ToString();
                if (!username.Equals("admin") && !password.Equals("admin"))
                {
                    Response.Redirect("Login.aspx?message=1");
                }
                shape.Enabled = false;
                type.Enabled = false;
                carat.Enabled = false;
                clarity.Enabled = false;
                price.Enabled = false;
                btn_delete.Enabled = false;
                btn_update.Enabled = false;
                DisplayGridView();
            }
        }

    private void DisplayGridView()
    {
        try { 
        GridView1.DataSource = null;
        GridView1.DataBind();

        cn.Open();
        int status = 0;
        String q = "select * from Table_collection where status=@status";
        
        SqlCommand cmd = new SqlCommand(q,cn);
        cmd.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        cn.Close();
        }catch(Exception e)
        {
            Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
            //Response.Redirect("addcollection.aspx");
        }
    }
    protected void GridView1Selected(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        cid.Text = gr.Cells[1].Text;
        shape.Text = gr.Cells[3].Text;
        shape.Enabled = true;
        type.Text = gr.Cells[4].Text;
        type.Enabled = true;
        carat.Text = gr.Cells[5].Text;
        carat.Enabled = true;
        clarity.Text = gr.Cells[6].Text;
        clarity.Enabled = true;
        price.Text = gr.Cells[7].Text;
        price.Enabled = true;
        btn_update.Enabled = true;
        btn_delete.Enabled = true;
    }

    protected void btn_update_Click(object sender, EventArgs e)
    {
        try
        { 
        cn.Open();
        SqlCommand cmd = new SqlCommand("update Table_collection set diamond_shape=@shape,diamond_type=@type,diamond_Carat=@carat,diamond_clarity=@clarity,diamond_price=@price where collection_id=@id ",cn);
        cmd.Parameters.AddWithValue("@shape",shape.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@type", type.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@carat", carat.Text);
        cmd.Parameters.AddWithValue("@clarity", clarity.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@price", price.Text);
        cmd.Parameters.AddWithValue("@id", cid.Text);
        int i=cmd.ExecuteNonQuery();
        if(i==1)
        {
            Response.Write("<script>alert('Updated!!')</script>");
            Response.Redirect("addcollection.aspx");
        }
        else
        {
            Response.Write("<script>alert('Something Wrong!!')</script>");
        }
        cn.Close();
        }
        catch (Exception e3)
        {
            Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
        //    Response.Redirect("addcollection.aspx");
        }

        shape.Enabled = false;
        type.Enabled = false;
        carat.Enabled = false;
        clarity.Enabled = false;
        price.Enabled = false;
        btn_delete.Enabled = false;
        btn_update.Enabled = false;
        DisplayGridView();
    }

    protected void btn_delete_Click(object sender, EventArgs e)
    {
        int status = 1;
        try
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("update Table_collection set status=@status where collection_id=@id ", cn);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@id", cid.Text);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Deleted!!')</script>");
                Response.Redirect("addcollection.aspx");
            }
            else
            {
                Response.Write("<script>alert('Still Not Deleted!!')</script>");
            }
            cn.Close();
        }
        catch (Exception e2)
        {
            Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
        //    Response.Redirect("addcollection.aspx");
        }
        shape.Enabled = false;
        type.Enabled = false;
        carat.Enabled = false;
        clarity.Enabled = false;
        price.Enabled = false;
        btn_delete.Enabled = false;
        btn_update.Enabled = false;
        DisplayGridView();
    }

    

    protected void Button_submit_Click(object sender, EventArgs e)
        {

            a = Class1.GetRandomPassword(10).ToString();
            FileUpload1.SaveAs(Request.PhysicalApplicationPath + "./images/" + a + FileUpload1.FileName.ToString());
            b = "./images/" + a + FileUpload1.FileName.ToString();
            int status = 0;
        try
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("insert into Table_collection(collection_image,diamond_shape,diamond_type,diamond_Carat,diamond_clarity,diamond_price,status) values(@image,@shape,@type,@carat,@clarity,@price,@status) ", cn);
            cmd.Parameters.AddWithValue("@image", b.ToString());
            cmd.Parameters.AddWithValue("@shape", DropDownList_shape.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@type", DropDownList_type.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@carat", TextBox_carat.Text);
            cmd.Parameters.AddWithValue("@clarity", DropDownList_clarity.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@price", TextBox_price.Text);
            cmd.Parameters.AddWithValue("@status", status);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Inserted!!')</script>");
                Response.Redirect("addcollection.aspx");
            }
            else
            {
                Response.Write("<script>alert('Please fill Up All Appropriate Detail!!')</script>");
            }
            cn.Close();
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
        //    Response.Redirect("addcollection.aspx");
        }
        DisplayGridView();
        carat.Text = null;
        price.Text = null;
        }
    }

