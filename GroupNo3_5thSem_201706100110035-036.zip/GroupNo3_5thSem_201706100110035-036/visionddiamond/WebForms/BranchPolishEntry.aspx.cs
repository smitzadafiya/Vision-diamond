﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_BranchPolishEntry : System.Web.UI.Page
{
    SqlConnection conn;
    String lid, username, password, bid, AID, OP, PID;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            lid = Session["Lid"].ToString();
            username = Session["Username"].ToString();
            password = Session["Password"].ToString();
            bid = Session["BID"].ToString();
            AID = Request.QueryString["AID"];
            OP = Request.QueryString["OP"];
            if (lid == null || username == null || password == null || bid == null)
            {
                Response.Redirect("Login.aspx?message=1");
            }

            if (AID == null || OP == null)
            {
                Response.Redirect("BranchCutting.aspx");
            }
            if (!Page.IsPostBack)
            {
                if (OP.Equals("MakeEntry"))
                {
                    conn.Open();
                    String q = "select c.CompletionDate,c.MakableWeight,c.MakableQuantity,a.PurchaseID from tblPurchaseAllocation a,tblCutting c where a.AllocationID=@AID and c.AllocationID=a.AllocationID";
                    SqlCommand cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@AID", AID);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_CDate.Text = reader["CompletionDate"].ToString();
                    txt_MakableWeight.Text = reader["MakableWeight"].ToString();
                    txt_MakableQuantity.Text = reader["MakableQuantity"].ToString();
                    h_PID.Value = reader["PurchaseID"].ToString();
                    txt_Rate.Text = PID;
                    conn.Close();
                    btn_MakeEntry.Text = "Make Entry";
                    lbl_ReturnDate.Text = DateTime.Now.ToString();
                }
                else if (OP.Equals("UpdateEntry"))
                {
                    conn.Open();
                    String q = "select c.CompletionDate,c.MakableWeight,c.MakableQuantity,a.PurchaseID from tblPurchaseAllocation a,tblCutting c where a.AllocationID=@AID and c.AllocationID=a.AllocationID";
                    SqlCommand cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@AID", AID);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_CDate.Text = reader["CompletionDate"].ToString();
                    txt_MakableWeight.Text = reader["MakableWeight"].ToString();
                    txt_MakableQuantity.Text = reader["MakableQuantity"].ToString();
                    h_PID.Value = reader["PurchaseID"].ToString();
                    txt_Rate.Text = PID;
                    conn.Close();

                    conn.Open();
                    q = "select PolishedWeight,PolishedQuantity,Rate,ReturnDate from tblPolished where AllocationID=@AID";
                    cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@AID", AID);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    txt_PolishedWeight.Text = reader["PolishedWeight"].ToString();
                    txt_PolishedQuantity.Text = reader["PolishedQuantity"].ToString();
                    txt_Rate.Text = reader["Rate"].ToString();
                    lbl_ReturnDate.Text = reader["ReturnDate"].ToString();
                    conn.Close();
                    btn_MakeEntry.Text = "Update Entry";
                    totalamountChanged(sender, e);
                    MakableWeightChanged(sender, e);
                    MakableQuantityChanged(sender, e);
                }
            }
        }
    }

    protected void btn_MakeEntryClicked(object sender, EventArgs e)
    {
        //try
        //{
        if (OP.Equals("MakeEntry"))
        {
            conn.Open();
            String q = "insert into tblPolished (AllocationID,PolishedWeight,PolishedQuantity,Rate,ReturnDate) values (@AllocationID,@PolishedWeight,@PolishedQuantity,@Rate,GETDATE()) ";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@AllocationID", AID);
            cmd.Parameters.AddWithValue("@PolishedWeight", txt_PolishedWeight.Text);
            cmd.Parameters.AddWithValue("@PolishedQuantity", txt_PolishedQuantity.Text);
            cmd.Parameters.AddWithValue("@Rate", txt_Rate.Text);
            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i == 1)
            {
                conn.Open();
                q = "update tblPurchaseDetails set DiamondStatus=@DiamondStatus where PurchaseID=@PurchaseID";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@DiamondStatus", "4");
                cmd.Parameters.AddWithValue("@PurchaseID", h_PID.Value);
                i = cmd.ExecuteNonQuery();
                conn.Close();
                if (i == 1)
                {
                    Server.Transfer("BranchPolishEntry.aspx?AID=" + AID + "&OP=UpdateEntry");
                }
            }
        }
        else if (OP.Equals("UpdateEntry"))
        {
            conn.Open();
            String q = "update tblPolished set PolishedWeight=@PolishedWeight,PolishedQuantity=@PolishedQuantity,Rate=@Rate where AllocationID=@AllocationID";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@PolishedWeight", txt_PolishedWeight.Text);
            cmd.Parameters.AddWithValue("@PolishedQuantity", txt_PolishedQuantity.Text);
            cmd.Parameters.AddWithValue("@Rate", txt_Rate.Text);
            cmd.Parameters.AddWithValue("@AllocationID", AID);
            int i = cmd.ExecuteNonQuery();
            conn.Close();
            if (i == 1)
            {
                Server.Transfer("BranchPolishEntry.aspx?AID=" + AID + "&OP=UpdateEntry");
            }
        }

        /*}
        catch (Exception ex)
        {
            Response.Write(ex);
        }*/
    }

    protected void totalamountChanged(object sender, EventArgs e)
    {
        try
        {
            if (!txt_Rate.Text.Equals(""))
            {
                lbl_TotalAmount.Text = (Convert.ToDouble(txt_MakableQuantity.Text) * Convert.ToDouble(txt_Rate.Text)).ToString() + " Rs.";
            }
            else
            {
                lbl_TotalAmount.Text = "00 Rs.";
            }
        }catch(Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void MakableWeightChanged(object sender, EventArgs e)
    {
        try
        {
            if (!txt_PolishedWeight.Text.Equals(""))
            {
                txt_LostWeight.Text = (Convert.ToDouble(txt_MakableWeight.Text) - Convert.ToDouble(txt_PolishedWeight.Text)).ToString();
            }
            else
            {
                txt_LostWeight.Text = "";
            }
        }catch(Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void MakableQuantityChanged(object sender, EventArgs e)
    {
        try
        {
            if (!txt_PolishedQuantity.Text.Equals(""))
            {
                txt_LostQuantity.Text = (Convert.ToDouble(txt_MakableQuantity.Text) - Convert.ToDouble(txt_PolishedQuantity.Text)).ToString();
            }
            else
            {
                txt_LostQuantity.Text = "";
            }
        }catch(Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void btn_BackClicked(object sender, EventArgs e)
    {
        Response.Redirect("BranchPolish.aspx");
    }
}