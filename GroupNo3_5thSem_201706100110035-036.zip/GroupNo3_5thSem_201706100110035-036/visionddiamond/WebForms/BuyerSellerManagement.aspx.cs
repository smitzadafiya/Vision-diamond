﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_BuyerSellerManagement : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();
            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }
            if (!Page.IsPostBack)
            {
                drop_country.Items.Add("Select Country :-");
                country.Items.Add("Select Country :-");
                String q = "select * from tblCountry";
                conn.Open();
                SqlCommand cmd = new SqlCommand(q, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    drop_country.Items.Add(reader["CountryName"].ToString());
                    country.Items.Add(reader["CountryName"].ToString());
                }

                conn.Close();
                BranchGridView();
                clear1();
            }
        }
    }
    String cityName, stateName;
    protected void drop_country_TextChanged(object sender, EventArgs e)
    {
        drop_state.Items.Clear();
        drop_city.Items.Clear();
        drop_state.Items.Add("Select State :-");
        String q = "select s.StateName from tblState s,tblCountry c where c.CountryID = s.CountryID and c.CountryName='" + drop_country.Text + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(q, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            drop_state.Items.Add(reader["StateName"].ToString());
        }
        conn.Close();
    }

    protected void drop_state_changed(object sender, EventArgs e)
    {
        drop_city.Items.Clear();
        drop_city.Items.Add("Select City :-");
        String q = "select c.CityName from tblState s,tblCity c where c.StateID = s.StateID and s.StateName='" + drop_state.Text + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(q, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            drop_city.Items.Add(reader["CityName"].ToString());
        }
        conn.Close();
    }

    protected void country_TextChanged(object sender, EventArgs e)
    {
        state.Items.Clear();
        city.Items.Clear();
        state.Items.Add("Select State :-");
        String q = "select s.StateName from tblState s,tblCountry c where c.CountryID = s.CountryID and c.CountryName='" + country.Text + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(q, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            state.Items.Add(reader["StateName"].ToString());
        }
        conn.Close();
        if (stateName != null)
        {
            state.Text = stateName;
            stateName = null;
        }
    }

    protected void state_changed(object sender, EventArgs e)
    {
        city.Items.Clear();
        city.Items.Add("Select City :-");
        String q = "select c.CityName from tblState s,tblCity c where c.StateID = s.StateID and s.StateName='" + state.Text + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(q, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            city.Items.Add(reader["CityName"].ToString());
        }
        conn.Close();
        if (cityName != null)
        {
            city.Text = cityName;
            cityName = null;
        }
    }

    protected void btn_add_clicked(object sender, EventArgs e)
    {
        conn.Open();
        int status = 0;
        String q = "select CityID from tblCity where CityName=@city";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@city", drop_city.Text);
        
        SqlDataReader reader1 = cmd1.ExecuteReader();
        reader1.Read();
        String cid = reader1["CityID"].ToString();
        conn.Close();
        try
        {
            conn.Open();
            q = "insert into tblBuyerSeller (CompanyName,ContactNo,PanNo,GSTIN,Address,CityID,Email,status) values (@cname,@contactno,@pan,@gstin,@address,@cityid,@email,@status)";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@cname", txt_companyName.Text);
            cmd.Parameters.AddWithValue("@contactno", txt_contactNo.Text);
            cmd.Parameters.AddWithValue("@pan", txt_panNo.Text);
            cmd.Parameters.AddWithValue("@gstin", txt_gstin.Text);
            cmd.Parameters.AddWithValue("@address", txt_address.Value);
            cmd.Parameters.AddWithValue("@cityid", cid);
            cmd.Parameters.AddWithValue("@email", txt_email.Text);
            cmd.Parameters.AddWithValue("@status", status);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Inserted!!')</script>");
                Response.Redirect("BuyerSellerManagement.aspx");
            }
            else
            {
                Response.Write("<script>alert('Not Inserted!!')</script>");
            }
            conn.Close();
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Something Went Wrong!!!')</script>");
        //    Response.Redirect("BuyerSellerManagement.aspx");
        }

        BranchGridView();
        clear();
    }

    private void clear()
    {
        txt_companyName.Text = null;
        txt_contactNo.Text = null;
        txt_panNo.Text = null;
        txt_gstin.Text = null;
        txt_address.Value = null;
        txt_email.Text = null;
    }

    private void clear1()
    {
        bsid.Text = null;
        cname.Enabled = false;
        cname.Text = null;
        contact.Text = null;
        contact.Enabled = false;
        pan.Text = null;
        pan.Enabled = false;
        gstin.Text = null;
        gstin.Enabled = false;
        address.Value = null;
        email.Text = null;
        email.Enabled = false;
        country.Enabled = false;
        state.Enabled = false;
        city.Enabled = false;
        btn_update.Enabled = false;
        btn_delete.Enabled = false;
    }

    protected void btn_update_clicked(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            int status = 0;
            String q = "select CityID from tblCity where CityName=@city";
            SqlCommand cmd1 = new SqlCommand(q, conn);
            cmd1.Parameters.AddWithValue("@city", city.Text);

            SqlDataReader reader1 = cmd1.ExecuteReader();
            reader1.Read();
            String cid = reader1["CityID"].ToString();
            conn.Close();

            conn.Open();
            q = "update tblBuyerSeller set CompanyName=@cname,ContactNo=@contactno,PanNo=@pan,GSTIN=@gstin,Address=@address,CityID=@cityid,Email=@email where BuyerSellerID=@bsid and status=@status";

            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@cname", cname.Text);
            cmd.Parameters.AddWithValue("@contactno", contact.Text);
            cmd.Parameters.AddWithValue("@pan", pan.Text);
            cmd.Parameters.AddWithValue("@gstin", gstin.Text);
            cmd.Parameters.AddWithValue("@address", address.Value);
            cmd.Parameters.AddWithValue("@cityid", cid);
            cmd.Parameters.AddWithValue("@email", email.Text);
            cmd.Parameters.AddWithValue("@bsid", bsid.Text);
            cmd.Parameters.AddWithValue("@status", status);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Updated!!')</script>");
                Response.Redirect("BuyerSellerManagement.aspx");
            }
            else
            {
                Response.Write("<script>alert('Not Updated!!')</script>");
            }
            conn.Close();
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Something Went Wrong!!!')</script>");
       //     Response.Redirect("BuyerSellerManagement.aspx");
        }

        BranchGridView();
        clear1();
    }

    protected void btn_delete_clicked(object sender, EventArgs e)
    {
        conn.Open();
        int status = 1;
        String q = "update tblBuyerSeller set status=@status where BuyerSellerID=@bsid";
        SqlCommand cmd = new SqlCommand(q, conn);

        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@bsid",bsid.Text);
        
        int i = cmd.ExecuteNonQuery();
        if (i == 1)
        {
            Response.Write("<script>alert('Deleted!!')</script>");
            Response.Redirect("BuyerSellerManagement.aspx");
        }
        else
        {
            Response.Write("<script>alert('Not Deleted!!')</script>");
        }
        conn.Close();
        BranchGridView();
        clear1();
    }

    private void BranchGridView()
    { 

        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Close();
        conn.Open();
        String q = "select * from tblBuyerSeller where status=@status";
        SqlCommand cmd1 = new SqlCommand(q,conn);
        cmd1.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void BindData(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        bsid.Text = gr.Cells[1].Text;
        cname.Text = gr.Cells[2].Text;
        contact.Text = gr.Cells[3].Text;
        pan.Text = gr.Cells[4].Text;
        gstin.Text = gr.Cells[5].Text;
        address.Value = gr.Cells[6].Text;
        String cid = gr.Cells[7].Text;

        email.Text = gr.Cells[8].Text;
        state.Items.Clear();
        city.Items.Clear();

        conn.Open();
        String q = "select c.CityName,s.StateName,co.CountryName from tblCity c,tblState s,tblCountry co where c.StateID = s.StateID and s.CountryID = co.CountryID and c.CityID=@cid";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@cid", cid);
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        cityName = reader["CityName"].ToString();
        stateName = reader["StateName"].ToString();
        country.Text = reader["CountryName"].ToString();
        conn.Close();
        country_TextChanged(sender, e);
        state_changed(sender, e);

        cname.Enabled = true;
        contact.Enabled = true;
        pan.Enabled = true;
        gstin.Enabled = true;
        email.Enabled = true;
        country.Enabled = true;
        state.Enabled = true;
        city.Enabled = true;
        btn_update.Enabled = true;
        btn_delete.Enabled = true;
    }

    protected void btn_dashboard_clicked(object sender, EventArgs e)
    {
        Response.Redirect("AdminDashboard.aspx");
    }
}