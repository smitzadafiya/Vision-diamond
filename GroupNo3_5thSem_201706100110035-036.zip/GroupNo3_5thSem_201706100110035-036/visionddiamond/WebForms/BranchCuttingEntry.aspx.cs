﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_BranchCuttingEntry : System.Web.UI.Page
{
    SqlConnection conn;
    String lid, username, password, bid,AID,OP,PID;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            //try
            //{
                lid = Session["Lid"].ToString();
                username = Session["Username"].ToString();
                password = Session["Password"].ToString();
                bid = Session["BID"].ToString();
                AID = Request.QueryString["AID"];
                OP = Request.QueryString["OP"];
                if (lid == null || username == null || password == null || bid == null)
                {
                    Response.Redirect("Login.aspx?message=1");
                }

                if (AID == null || OP == null)
                {
                    Response.Redirect("BranchCutting.aspx");
                }
            if (!Page.IsPostBack)
            {
                if (OP.Equals("MakeEntry"))
                {
                    conn.Open();
                    String q = "select a.AllocationDate,a.Notes,a.PurchaseID,p.Weight from tblPurchaseAllocation a,tblPurchaseDetails p where a.AllocationID=@AID and p.PurchaseID=a.PurchaseID";
                    SqlCommand cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@AID", AID);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_ADate.Text = reader["AllocationDate"].ToString();
                    txt_Notes.Text = reader["Notes"].ToString();
                    h_PID.Value = reader["PurchaseID"].ToString();
                    lbl_Weight.Text = reader["Weight"].ToString();
                    conn.Close();
                    btn_MakeEntry.Text = "Make Entry";
                    lbl_CompletionDate.Text = DateTime.Now.ToString();
                }
                else if (OP.Equals("UpdateEntry"))
                {
                    conn.Open();
                    String q = "select a.AllocationDate,a.Notes,a.PurchaseID,p.Weight from tblPurchaseAllocation a,tblPurchaseDetails p where a.AllocationID=@AID and p.PurchaseID=a.PurchaseID";
                    SqlCommand cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@AID", AID);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_ADate.Text = reader["AllocationDate"].ToString();
                    txt_Notes.Text = reader["Notes"].ToString();
                    PID = reader["PurchaseID"].ToString();
                    lbl_Weight.Text = reader["Weight"].ToString();
                    conn.Close();

                    conn.Open();
                    q = "select Weight,RejectionWeight,MakableWeight,MakableQuantity,Rate,CompletionDate from tblCutting where AllocationID=@AID";
                    cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@AID", AID);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    lbl_Weight.Text = reader["Weight"].ToString();
                    txt_RejectionWeight.Text = reader["RejectionWeight"].ToString();
                    txt_MakableWeight.Text = reader["MakableWeight"].ToString();
                    txt_MakableQuantity.Text = reader["MakableQuantity"].ToString();
                    txt_Rate.Text = reader["Rate"].ToString();
                    lbl_CompletionDate.Text = reader["CompletionDate"].ToString();
                    conn.Close();
                    btn_MakeEntry.Text = "Update Entry";
                    totalamountChanged(sender, e);
                }
            }
                
                
            /*}
            catch (Exception ex)
            {
                Response.Redirect("Login.aspx?message=1");
            }*/
        }
    }

    protected void btn_BackClicked(object sender, EventArgs e)
    {
        Response.Redirect("BranchCutting.aspx");
    }

    protected void btn_MakeEntryClicked(object sender, EventArgs e)
    {
        //try
        //{
            if (OP.Equals("MakeEntry"))
            {
                conn.Open();
                String q = "insert into tblCutting (AllocationID,Weight,RejectionWeight,MakableWeight,MakableQuantity,Rate,CompletionDate) values (@AllocationID,@Weight,@RejectionWeight,@MakableWeight,@MakableQuantity,@Rate,GETDATE()) ";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@AllocationID", AID);
                cmd.Parameters.AddWithValue("@Weight", lbl_Weight.Text);
                cmd.Parameters.AddWithValue("@RejectionWeight", txt_RejectionWeight.Text);
                cmd.Parameters.AddWithValue("@MakableWeight", txt_MakableWeight.Text);
                cmd.Parameters.AddWithValue("@MakableQuantity", txt_MakableQuantity.Text);
                cmd.Parameters.AddWithValue("@Rate", txt_Rate.Text);
               // cmd.Parameters.AddWithValue("@CompletionDate", DateTime.Now.ToString("dd/MM/yyyy"));
                int i = cmd.ExecuteNonQuery();
                conn.Close();

                conn.Open();
                q = "insert into tblRejection (AllocationID,RejectionWeight,Status) values (@AllocationID,@RejectionWeight,@Status)";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@AllocationID", AID);
                cmd.Parameters.AddWithValue("@RejectionWeight", txt_RejectionWeight.Text);
                cmd.Parameters.AddWithValue("@Status", "1");
                i = cmd.ExecuteNonQuery();
                conn.Close();

                conn.Open();
                String q1 = "update tblPurchaseDetails set DiamondStatus='3' where PurchaseID='"+h_PID.Value+"'";
                SqlCommand cmd1 = new SqlCommand(q1, conn);
                cmd1.ExecuteNonQuery();
                conn.Close();

                Server.Transfer("BranchCuttingEntry.aspx?AID=" + AID + "&OP=UpdateEntry");
                        
                
            }
            else if(OP.Equals("UpdateEntry"))
            {
                conn.Open();
                String q = "update tblCutting set RejectionWeight=@RejectionWeight,MakableWeight=@MakableWeight,MakableQuantity=@MakableQuantity,Rate=@Rate where AllocationID=@AID ";
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@RejectionWeight", txt_RejectionWeight.Text);
                cmd.Parameters.AddWithValue("@MakableWeight", txt_MakableWeight.Text);
                cmd.Parameters.AddWithValue("@MakableQuantity", txt_MakableQuantity.Text);
                cmd.Parameters.AddWithValue("@Rate", txt_Rate.Text);
                cmd.Parameters.AddWithValue("@AID", AID);
            
                int i = cmd.ExecuteNonQuery();
                conn.Close();
                if (i == 1)
                {
                    conn.Open();
                    q = "Update tblRejection set RejectionWeight=@RejectionWeight where AllocationID=@AllocationID";
                    cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@RejectionWeight", txt_RejectionWeight.Text);
                    cmd.Parameters.AddWithValue("@AllocationID", AID);
                    i = cmd.ExecuteNonQuery();
                    conn.Close();

                    if (i == 1)
                    {
                        Server.Transfer("BranchCuttingEntry.aspx?AID=" + AID + "&OP=UpdateEntry");
                    }
                }
            }
            
        /*}
        catch (Exception ex)
        {
            Response.Write(ex);
        }*/
    }
    protected void makableweightChanged(object sender, EventArgs e)
    {
        try
        {
            if (!txt_RejectionWeight.Text.Equals(""))
            {
                txt_MakableWeight.Text = (Convert.ToDouble(lbl_Weight.Text) - Convert.ToDouble(txt_RejectionWeight.Text)).ToString();
            }
            else
            {
                txt_MakableWeight.Text = "";
            }
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void totalamountChanged(object sender, EventArgs e)
    {
        try
        {
            if (!txt_Rate.Text.Equals(""))
            {
                lbl_TotalAmount.Text = (Convert.ToDouble(lbl_Weight.Text) * Convert.ToDouble(txt_Rate.Text)).ToString();
            }
            else
            {
                lbl_TotalAmount.Text = "00 Rs.";
            }
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }
}