﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_SearchRecoard : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }
        }
    }

    protected void btn_findClicked(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Close();
        conn.Open();
        String q = "select PurchaseID,InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount from tblPurchaseDetails where Status=@status and PurchaseDate between @startDate and @endDate";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        cmd1.Parameters.AddWithValue("@startDate", txt_startDate.Text);
        cmd1.Parameters.AddWithValue("@endDate", txt_lastDate.Text);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();

    }
    protected void btn_sevendays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Close();
        conn.Open();
        String q = "select PurchaseID,InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount from tblPurchaseDetails where Status=@status and PurchaseDate >= DATEADD(DAY, -7,GETDATE()) and PurchaseDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_thirtyDays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Close();
        conn.Open();
        String q = "select PurchaseID,InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount from tblPurchaseDetails where Status=@status and PurchaseDate >= DATEADD(MONTH, -1,GETDATE()) and PurchaseDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_nintyDays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Close();
        conn.Open();
        String q = "select PurchaseID,InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount from tblPurchaseDetails where Status=@status and PurchaseDate >= DATEADD(MONTH, -3,GETDATE()) and PurchaseDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_oneYear(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Close();
        conn.Open();
        String q = "select PurchaseID,InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount from tblPurchaseDetails where Status=@status and PurchaseDate >= DATEADD(YEAR, -1,GETDATE()) and PurchaseDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_allTime(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Close();
        conn.Open();
        String q = "select PurchaseID,InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount from tblPurchaseDetails where Status=@status";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void FullDescription(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        Server.Transfer("PurchaseFullDescription.aspx?pid=" + gr.Cells[1].Text);
    }

}
