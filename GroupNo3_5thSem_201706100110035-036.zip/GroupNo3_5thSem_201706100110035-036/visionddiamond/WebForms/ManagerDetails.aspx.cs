﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_ManagerDetails : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);

        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }
        }
        ManagerDetailsGridView();
    }

    private EventHandler btnUpdate_Click(String mid)
    {
        txt_managerName.Text = mid.ToString();
        throw new NotImplementedException();
    }

    protected void btn_dashboard_clicked(object sender, EventArgs e)
    {
        Response.Redirect("AdminDashboard.aspx");
    }

    protected void btn_branch_clicked(object sender, EventArgs e)
    {
        Response.Redirect("BranchManagement.aspx");
    }

    protected void BindData(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        managerId.Text = gr.Cells[1].Text;
        managerName.Enabled = true;
        managerName.Text = gr.Cells[2].Text;
        mobileNo.Text = gr.Cells[3].Text;
        mobileNo.Enabled = true;
        adhar.Text = gr.Cells[4].Text;
        adhar.Enabled = true;
        address.Value = gr.Cells[5].Text;
        email.Text = gr.Cells[6].Text;
        email.Enabled = true;
        btn_update.Enabled = true;
        btn_delete.Enabled = true;
    }

    protected void btn_add_clicked(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            int status = 0;
            String q = "insert into tblManager (ManagerName,MobileNo,AdharCardNo,Address,EmailAddress,status) values (@mname,@mobileno,@adharno,@address,@email,@status)";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@mname", txt_managerName.Text);
            cmd.Parameters.AddWithValue("@mobileno", txt_mobileNo.Text);
            cmd.Parameters.AddWithValue("@adharno", txt_adhar.Text);
            cmd.Parameters.AddWithValue("@address", txt_address.Value);
            cmd.Parameters.AddWithValue("@email", txt_email.Text);
            cmd.Parameters.AddWithValue("@status", status);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                // Response.Write("Inserted!!");
                Response.Write("<script>alert('Inserted!!')</script>");
            }
            else
            {
                // Response.Write(" Not Inserted!!");
                Response.Write("<script>alert('Not Inserted!!')</script>");
            }
            conn.Close();
            ManagerDetailsGridView();
            ClearData();
        }
        catch (Exception e1) {
            Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
        }
    }

    protected void btn_update_clicked(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            int status = 0;
            String q = "update tblManager set ManagerName=@ManagerName,MobileNo=@mobileno,AdharCardNo=@adharno,Address=@address,EmailAddress=@email where ManagerID=@mid and status=@status";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@mid", managerId.Text);
            cmd.Parameters.AddWithValue("@ManagerName",managerName.Text);
            cmd.Parameters.AddWithValue("@mobileno", mobileNo.Text);
            cmd.Parameters.AddWithValue("@adharno", adhar.Text);
            cmd.Parameters.AddWithValue("@address", address.Value);
            cmd.Parameters.AddWithValue("@email", email.Text);
            cmd.Parameters.AddWithValue("@status", status);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Updated!!')</script>");
                // Response.Write("Updated !!");
            }
            else
            {
                Response.Write("<script>alert('Not Updated!!')</script>");
                //Response.Write("Not Updated !!");
            }
            conn.Close();
        }catch(Exception e1)
        {
            Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
        }
        ManagerDetailsGridView();
        ClearData1();
    }

    protected void btn_delete_clicked(object sender, EventArgs e)
    {
        conn.Open();
        int status = 1;
        String q = "update tblManager set status=@status where ManagerID=@mid";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@mid", managerId.Text);
        
        int i = cmd.ExecuteNonQuery();
        if (i == 1)
        {
            Response.Write("<script>alert('Deleted!!')</script>");
            //Response.Write("Deleted !!");
        }
        else
        {
            Response.Write("<script>alert('Not Deleted !!')</script>");
            //Response.Write("Not Deleted !!");
        }

        conn.Close();
        ManagerDetailsGridView();
        ClearData1();
    }

    private void ManagerDetailsGridView()
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        String q = "select * from tblManager where status=@status";

        conn.Open();
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    private void ClearData()
    {
        txt_managerName.Text = null;
        txt_address.Value = null;
        txt_mobileNo.Text = null;
        txt_adhar.Text = null;
        txt_email.Text = null;
    }

    private void ClearData1()
    {
        managerId.Text = null;
        managerName.Text = null;
        address.Value = null;
        mobileNo.Enabled = false;
        mobileNo.Text = null;
        adhar.Enabled = false;
        adhar.Text = null;
        email.Enabled = false;
        email.Text = null;
    }

    protected void btn_logout_clicked(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx?message=2");
        Session.Abandon();
    }
}