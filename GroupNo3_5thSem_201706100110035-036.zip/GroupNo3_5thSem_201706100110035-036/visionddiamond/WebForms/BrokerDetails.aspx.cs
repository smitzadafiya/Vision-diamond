﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_BrokerDetails : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();
            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }
            if (!Page.IsPostBack)
            {
                BranchGridView();
                clear1();
            }
        }
    }
    protected void btn_add_clicked(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            int status = 0;
            String q = "insert into tblBroker (BrokerName,BrokerAddress,MobileNo,Email,status) values (@bname,@address,@mno,@email,@status)";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@bname", txt_brokerName.Text);
            cmd.Parameters.AddWithValue("@address", txt_address.Value);
            cmd.Parameters.AddWithValue("@mno", txt_mobileNo.Text);
            cmd.Parameters.AddWithValue("@email", txt_email.Text);
            cmd.Parameters.AddWithValue("@status", status);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {

                Response.Write("<script>alert('Inserted!!')</script>");
                Response.Redirect("BrokerDetails.aspx");
            }
            else
            {
                Response.Write("<script>alert('Something went Wrong!!')</script>");

            }
            conn.Close();
        }
        catch(Exception e1)
        {
            Response.Write("<script>alert('Something Went Wrong!!!')</script>");
        //    Response.Redirect("BrokerDetails.aspx");
        }
        BranchGridView();
        clear();
    }

    protected void btn_update_clicked(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            int status = 0;
            String q = "update tblBroker set BrokerName=@bname,BrokerAddress=@address,MobileNo=@mno,Email=@email where BrokerID=@bid and status=@status";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@bname", bname.Text);
            cmd.Parameters.AddWithValue("@address", address.Value);
            cmd.Parameters.AddWithValue("@mno", mno.Text);
            cmd.Parameters.AddWithValue("@email", email.Text);
            cmd.Parameters.AddWithValue("@bid", bid.Text);
            cmd.Parameters.AddWithValue("@status", status);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Updated!!')</script>");
                Response.Redirect("BrokerDetails.aspx");
            }
            else
            {
                Response.Write("<script>alert('Something Wrong!!')</script>");

            }
            conn.Close();
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Something Went Wrong!!!')</script>");
         //   Response.Redirect("BrokerDetails.aspx");
        }

        BranchGridView();
        clear1();
    }

    protected void btn_delete_clicked(object sender, EventArgs e)
    {
        conn.Open();
        int status = 1;
        String q = "update tblBroker set status=@status where BrokerID=@bid";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@bid", bid.Text);
        
        int i = cmd.ExecuteNonQuery();
        if (i == 1)
        {
            Response.Write("<script>alert('Deleted!!')</script>");
            Response.Redirect("BrokerDetails.aspx");
        }
        else
        {
            Response.Write("<script>alert('Not Deleted!!')</script>");
        }
        conn.Close();
        BranchGridView();
        clear1();
    }

    private void BranchGridView()
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Open();
        String q = "select * from tblBroker where status=@status";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void BindData(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        bid.Text = gr.Cells[1].Text;
        bname.Text = gr.Cells[2].Text;
        address.Value = gr.Cells[3].Text;
        mno.Text = gr.Cells[4].Text;
        email.Text = gr.Cells[5].Text;
        mno.Enabled = true;
        email.Enabled = true;
        btn_update.Enabled = true;
        btn_delete.Enabled = true;
    }

    private void clear()
    {
        txt_brokerName.Text = null;
        txt_address.Value = null;
        txt_mobileNo.Text = null;
        txt_email.Text = null;
    }

    private void clear1()
    {
        bid.Text = null;
        bname.Text = null;
        address.Value = null;
        mno.Text = null;
        email.Text = null;
        bname.Enabled = false;
        mno.Enabled = false;
        email.Enabled = false;
        btn_update.Enabled = false;
        btn_delete.Enabled = false;
    }

    protected void btn_dashboard_clicked(object sender, EventArgs e)
    {
        Response.Redirect("AdminDashboard.aspx");
    }

}