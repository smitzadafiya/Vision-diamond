﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Net;

public partial class WebForms_email : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }
        }
    }

    protected void send_reminder(object sender, EventArgs e)
    {
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        smtp.Port = 587;
        smtp.Credentials = new System.Net.NetworkCredential("Srzsmitzadafiya78@gmail.com", "78Smit78");
        smtp.EnableSsl = true;
        MailMessage msg = new MailMessage();
        msg.Subject = "!!!! Reminder !!! From Vision Diamond ";
        msg.Body = "This is for You :- \n" + message.Value + "\n From , \n Vision Diamond , Thanks";
        string toaddress = email.Text;
        msg.To.Add(toaddress);
        string fromaddress = "Srzsmitzadafiya78@gmail.com";
        msg.From = new MailAddress(fromaddress);
        //OTP = new string(mypass);

        try
        {
            smtp.Send(msg);
            Response.Write("<script>alert('Mail Successfully Send')</script>");

        }
        catch
        {
            throw;
        }
    }
    protected void back(object sender, EventArgs e)
    {
        Response.Redirect("reminder.aspx");
    }
}