﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_BranchCutting : System.Web.UI.Page
{
    SqlConnection conn;
    String lid, username, password, bid;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            try
            {
                lid = Session["Lid"].ToString();
                username = Session["Username"].ToString();
                password = Session["Password"].ToString();
                bid = Session["BID"].ToString();
                
                if (lid == null || username == null || password == null || bid == null)
                {
                    Response.Redirect("Login.aspx?message=1");
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("Login.aspx?message=1");
            }

            conn.Open();
            String q = "select a.AllocationID,p.Weight,a.AllocationDate,a.Notes from tblPurchaseAllocation a,tblPurchaseDetails p where a.BranchID=@bid and a.Status=@status and p.PurchaseID=a.PurchaseID and p.DiamondStatus='2' and p.Status='0'";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@bid", bid);
            cmd.Parameters.AddWithValue("@status", "0");
            Grid_CuttingEntry.DataSource = cmd.ExecuteReader();
            Grid_CuttingEntry.DataBind();
            conn.Close();

            conn.Open();
            q = "select a.AllocationID,c.CompletionDate,c.Weight,c.MakableWeight,c.MakableQuantity,c.Rate from tblPurchaseAllocation a,tblPurchaseDetails p,tblCutting c where a.BranchID=@bid and c.AllocationID=a.AllocationID and a.Status=@status and p.PurchaseID=a.PurchaseID and p.DiamondStatus='3' and p.Status='0'";
            cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@bid", bid);
            cmd.Parameters.AddWithValue("@status", "0");
            GridUpdateEntry.DataSource = cmd.ExecuteReader();
            GridUpdateEntry.DataBind();
            conn.Close();

        }
    }

    protected void MakeEntry(object sender, EventArgs e)
    {
        GridViewRow gr = Grid_CuttingEntry.SelectedRow;
        String AID = gr.Cells[1].Text;
        Server.Transfer("BranchCuttingEntry.aspx?AID=" + AID + "&OP=MakeEntry");
    }

    protected void UpdateEntry(object sender, EventArgs e)
    {
        GridViewRow gr = GridUpdateEntry.SelectedRow;
        String AID = gr.Cells[1].Text;
        Server.Transfer("BranchCuttingEntry.aspx?AID=" + AID + "&OP=UpdateEntry");
    }
}