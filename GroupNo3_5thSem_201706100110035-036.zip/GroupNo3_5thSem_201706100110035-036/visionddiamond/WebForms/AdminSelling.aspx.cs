﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_AdminSelling : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);

        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }

            conn.Open();
            String q = "select p.PurchaseID,p.InvoiceNo,p.PurchaseDate,p.Description,p.Weight,p.Amount,bs.CompanyName from tblPurchaseDetails p,tblBuyerSeller bs where bs.BuyerSellerID=p.BuyerSellerID and p.Status=@Status and (p.DiamondStatus='1' or p.DiamondStatus='6')";
            SqlCommand cmd = new SqlCommand(q,conn);
            cmd.Parameters.AddWithValue("@Status","0");
            Grid_RoughDiamond.DataSource = cmd.ExecuteReader();
            Grid_RoughDiamond.DataBind();
            conn.Close();

            conn.Open();
            q = "select p.PurchaseID,p.InvoiceNo,p.PurchaseDate,p.Description,p.Weight,p.Amount,bs.CompanyName from tblPurchaseDetails p,tblBuyerSeller bs where bs.BuyerSellerID=p.BuyerSellerID and p.Status=@Status and (p.DiamondStatus='8' or p.DiamondStatus='9')";
            cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@Status", "0");
            Grid_PurchasedPolishedSell.DataSource = cmd.ExecuteReader();
            Grid_PurchasedPolishedSell.DataBind();
            conn.Close();

            conn.Open();
            q = "select pd.AllocationID,p.InvoiceNo,p.PurchaseDate,p.Description,p.Weight,pd.PolishedWeight,p.Amount,bs.CompanyName from tblPolished pd,tblPurchaseAllocation a,tblPurchaseDetails p,tblBuyerSeller bs where a.AllocationID=pd.AllocationID and p.PurchaseID=a.PurchaseID and bs.BuyerSellerID=p.BuyerSellerID and p.Status=@Status and (p.DiamondStatus='5' or p.DiamondStatus='7')";
            cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@Status", "0");
            Grid_PolishedSell.DataSource = cmd.ExecuteReader();
            Grid_PolishedSell.DataBind();
            conn.Close();

            conn.Open();
            q = "select RejectionID,RejectionWeight from tblRejection where (Status='2' or Status='3')";
            cmd = new SqlCommand(q, conn);
            Grid_RejectionSell.DataSource = cmd.ExecuteReader();
            Grid_RejectionSell.DataBind();
            conn.Close();
        }
    }

    protected void btn_GetInvoiceClicked(object sender, EventArgs e)
    {
        Response.Redirect("AdminSalesInvoice.aspx");
    }

    protected void Grid_RoughClicked(object sender, EventArgs e)
    {
        GridViewRow gr = Grid_RoughDiamond.SelectedRow;
        Server.Transfer("AdminSalesEntry.aspx?PID=" + gr.Cells[1].Text + "&OP=MakeEntry");
    }

    protected void Grid_PurchasedPolishClicked(object sender, EventArgs e)
    {
        GridViewRow gr = Grid_PurchasedPolishedSell.SelectedRow;
        Server.Transfer("AdminPurchasePolishedDiamondEntry.aspx?PID=" + gr.Cells[1].Text + "&OP=MakeEntry");        
    }

    protected void Grid_PolishedClicked(object sender, EventArgs e)
    {
        GridViewRow gr = Grid_PolishedSell.SelectedRow;
        Server.Transfer("AdminPolishedSellEntry.aspx?AID=" + gr.Cells[1].Text + "&OP=MakeEntry");        
    }

    protected void Grid_RejectionClicked(object sender, EventArgs e)
    {
        GridViewRow gr = Grid_RejectionSell.SelectedRow;
        Server.Transfer("AdminRejectionSellEntry.aspx?RID=" + gr.Cells[1].Text + "&OP=MakeEntry");
    }
}