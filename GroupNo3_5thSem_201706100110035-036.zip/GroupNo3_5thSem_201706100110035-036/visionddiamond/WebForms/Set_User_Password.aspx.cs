﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_Set_User_Password : System.Web.UI.Page
{
    String uname, passwd, BID;
    SqlConnection conn;
    String status;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }

            BID = Request.QueryString["BID"];
                if (BID!=null)
                {
                    conn.Open();
                    String q = "select * from Login where Branch_ID = @bid";
                    SqlCommand cmd = new SqlCommand(q, conn);
                    cmd.Parameters.AddWithValue("@bid", BID.ToString());
                    SqlDataReader reader = cmd.ExecuteReader();
                    int flag = 0;
                    while (reader.Read())
                    {
                        flag = 1;
                        uname = reader["Username"].ToString();
                        passwd = reader["Password"].ToString();
                    }
                    conn.Close();

                    if (flag == 1)
                    {
                        txt_userName.Text = uname;
                        txt_Password.Text = passwd;
                        btn_Operation.Text = "Update";
                        status = "update";
                        conn.Open();
                        String q1 = "select BranchName from tblBranch where BranchID=@bid";
                        SqlCommand cmd1 = new SqlCommand(q1, conn);
                        cmd1.Parameters.AddWithValue("@bid",BID.ToString());
                        SqlDataReader read = cmd1.ExecuteReader();
                        read.Read();
                        lbl_bid.Text = read["BranchName"].ToString();
                        conn.Close();
                    }
                    else if (flag == 0)
                    {
                        btn_Operation.Text = "Set";
                        status = "set";
                        conn.Open();
                        String q1 = "select BranchName from tblBranch where BranchID=@bid";
                        SqlCommand cmd1 = new SqlCommand(q1, conn);
                        cmd1.Parameters.AddWithValue("@bid", BID.ToString());
                        SqlDataReader read = cmd1.ExecuteReader();
                        read.Read();
                        lbl_bid.Text = read["BranchName"].ToString();
                        conn.Close();
                }  
                }
                else
                {
                    Response.Redirect("BranchManagement.aspx");
                }
            
        }
    }

    protected void btn_Operation_Clicked(object sender, EventArgs e)
    {
        if (status.Equals("update"))
        {
            int status1 = 0;
            conn.Open();
            String q = "update Login set Username=@uname,Password=@passwd where status=@status)";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@uname", txt_userName.Text);
            cmd.Parameters.AddWithValue("@passwd", txt_Password.Text);
            cmd.Parameters.AddWithValue("@bid", BID);
            cmd.Parameters.AddWithValue("@status", status1);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Updated!!')</script>");
            }
            else
            {
                Response.Write("<script>alert('Somthing went wrong !!')</script>");
            }
            conn.Close();
        }
        else if(status.Equals("set"))
        {
            conn.Open();
            int status1 = 0;
            String q = "insert into Login (Username,Password,Branch_ID,status) values (@uname,@passwd,@bid,@status)";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@uname", txt_userName.Text);
            cmd.Parameters.AddWithValue("@passwd", txt_Password.Text);
            cmd.Parameters.AddWithValue("@bid", BID);
            cmd.Parameters.AddWithValue("@status", status1);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Sucessfully set!!')</script>");
            }
            else
            {
                Response.Write("<script>alert('Somthing went wrong !!')</script>");
            }
            conn.Close();
        }
    }

    protected void btn_Back_Clicked(object sender, EventArgs e)
    {
        Response.Redirect("BranchManagement.aspx");
    }
}