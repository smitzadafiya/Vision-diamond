﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_AdminSalesInvoice : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);

        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }
        }
    }

    protected void btn_BackClicked(object sender, EventArgs e)
    {
        Response.Redirect("AdminSelling.aspx");
    }

    protected void btn_findClicked(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select sell.InvoiceNo,sell.SellingDate,sell.DayTerm,sell.Weight,sell.Rate,bs.CompanyName from tblSales sell,tblBuyerSeller bs where bs.BuyerSellerID=sell.BuyerSellerID and sell.SellingDate between @startDate and @endDate";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@startDate", txt_startDate.Text);
        cmd1.Parameters.AddWithValue("@endDate", txt_lastDate.Text);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();

    }

    protected void btn_FindInvoiceClicked(object sender, EventArgs e)
    {
        Server.Transfer("AdminGetSalesInvoice.aspx?InvoiceNo=" + txt_InvoiceNo.Text);
    }

    protected void btn_GetInvoiceClicked(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        Server.Transfer("AdminGetSalesInvoice.aspx?InvoiceNo=" + gr.Cells[1].Text);
    }

    protected void btn_sevendays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select sell.InvoiceNo,sell.SellingDate,sell.DayTerm,sell.Weight,sell.Rate,bs.CompanyName from tblSales sell,tblBuyerSeller bs where bs.BuyerSellerID=sell.BuyerSellerID and sell.SellingDate >= DATEADD(DAY, -7,GETDATE()) and sell.SellingDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_thirtyDays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select sell.InvoiceNo,sell.SellingDate,sell.DayTerm,sell.Weight,sell.Rate,bs.CompanyName from tblSales sell,tblBuyerSeller bs where bs.BuyerSellerID=sell.BuyerSellerID and sell.SellingDate >= DATEADD(MONTH, -1,GETDATE()) and sell.SellingDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_nintyDays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select sell.InvoiceNo,sell.SellingDate,sell.DayTerm,sell.Weight,sell.Rate,bs.CompanyName from tblSales sell,tblBuyerSeller bs where bs.BuyerSellerID=sell.BuyerSellerID and sell.SellingDate >= DATEADD(MONTH, -3,GETDATE()) and sell.SellingDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_oneYear(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select sell.InvoiceNo,sell.SellingDate,sell.DayTerm,sell.Weight,sell.Rate,bs.CompanyName from tblSales sell,tblBuyerSeller bs where bs.BuyerSellerID=sell.BuyerSellerID and sell.SellingDate >= DATEADD(YEAR, -1,GETDATE()) and sell.SellingDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_allTime(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select sell.InvoiceNo,sell.SellingDate,sell.DayTerm,sell.Weight,sell.Rate,bs.CompanyName from tblSales sell,tblBuyerSeller bs where bs.BuyerSellerID=sell.BuyerSellerID";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void FullDescription(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        Server.Transfer("AdminCuttingCompleteReport.aspx?aid=" + gr.Cells[1].Text);
    }
}