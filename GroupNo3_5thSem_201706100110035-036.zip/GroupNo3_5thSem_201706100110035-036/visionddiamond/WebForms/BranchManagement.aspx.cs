﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class WebForms_BranchManagement : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();
            if (!Page.IsPostBack)
            {
                drop_country.Items.Add("Select Country :-");
                String q = "select * from tblCountry";
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(q, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        drop_country.Items.Add(reader["CountryName"].ToString());
                    }

                    conn.Close();
                }
                catch (Exception e1)
                {
                    Response.Write("'" + e1 + "'<script>alert('Something Went Wrong !! Please try again.. ')</script>");
                    Response.Redirect("BranchManagement.aspx");
                }
                q = "select ManagerID,ManagerName from tblManager where status='"+0+"'";
                conn.Open();
                SqlCommand cmd1 = new SqlCommand(q, conn);
             //   cmd1.Parameters.AddWithValue("@status", SqlDbType.Int).Value = status1;
                
                drop_manager.DataValueField = "ManagerID";
                drop_manager.DataTextField = "ManagerName";
                drop_manager.DataSource = cmd1.ExecuteReader();
                drop_manager.DataBind();
                conn.Close();

                conn.Open();
                cmd1 = new SqlCommand(q, conn);
                manager.DataValueField = "ManagerID";
                manager.DataTextField = "ManagerName";
                manager.DataSource = cmd1.ExecuteReader();
                manager.DataBind();
                conn.Close();

                ViewManager();
                ViewManagerUpdate();
                BranchGridView();
                ClearData1();
            }
        }
    }
    private void ClearData()
    {
        txt_branchName.Text = null;
        txt_contactNo.Text = null;
        txt_address.Value = null;
        drop_country.Text = "Select Country :-";
    }

    private void ClearData1()
    {
        txt_bname.Text = null;
        txt_cno.Text = null;
        txt_place.Value = null;
        txt_bname.Enabled = false;
        txt_cno.Enabled = false;
        btn_update.Enabled = false;
        btn_delete.Enabled = false;
        manager.Enabled = false;
        btn_set.Enabled = false;
        
    }

    protected void drop_state_changed(object sender, EventArgs e)
    {
        drop_city.Items.Clear();
        drop_city.Items.Add("Select City :-");
        String q = "select c.CityName from tblState s,tblCity c where c.StateID = s.StateID and s.StateName='" + drop_state.Text + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(q, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            drop_city.Items.Add(reader["CityName"].ToString());
        }
        conn.Close();
    }

    protected void btn_set_Clicked(object sender, EventArgs e)
    {
        Response.Redirect("Set_User_Password.aspx?BID=" + lbl_bid.Text);
    }

    protected void btn_add_clicked(object sender, EventArgs e)
    {

        if(txt_branchName.Text==null || txt_contactNo.Text==null || txt_address==null)
        {
            Response.Write("<script>alert('Please Fill all details First!!')</script>");
            Response.Redirect("BranchManagement.aspx");
        }
        else { 
        conn.Open();
        int status = 0;
        String q = "select CityID from tblCity where CityName=@city ";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@city", drop_city.Text);
        SqlDataReader reader1 = cmd1.ExecuteReader();
        reader1.Read();
        String cid = reader1["CityID"].ToString();
        conn.Close();

            try
            {
                conn.Open();
                q = "insert into tblBranch (BranchName,ContactNo,Address,CityID,ManagerID,status) values (@bname,@cno,@address,@city,@mid,@status)";
                cmd1 = new SqlCommand(q, conn);
                cmd1.Parameters.AddWithValue("@bname", txt_branchName.Text);
                cmd1.Parameters.AddWithValue("@cno", txt_contactNo.Text);
                cmd1.Parameters.AddWithValue("@address", txt_address.Value);
                cmd1.Parameters.AddWithValue("@city", cid);
                cmd1.Parameters.AddWithValue("@mid", drop_manager.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("@status", status);
                int i = cmd1.ExecuteNonQuery();
                if (i == 1)
                {
                    Response.Write("<script>alert('Inserted!!')</script>");
                    Response.Redirect("BranchManagement.aspx");
                }
                else
                {
                    Response.Write("<script>alert('NOt Inserted!!')</script>");
                }
                conn.Close();
            }
            catch (Exception e3)
            {
                Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
            //    Response.Redirect("BranchManagement.aspx");
            }
            ClearData();
        BranchGridView();
        }
    }

    protected void btn_update_clicked(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            int status = 0;
            String q = "update tblBranch set BranchName=@bname,ContactNo=@cno,Address=@address,ManagerID=@mid where BranchID=@bid and status=@status";
            SqlCommand cmd1 = new SqlCommand(q, conn);

            cmd1.Parameters.AddWithValue("@bname", txt_bname.Text);
            cmd1.Parameters.AddWithValue("@cno", txt_cno.Text);
            cmd1.Parameters.AddWithValue("@address", txt_place.Value);
            cmd1.Parameters.AddWithValue("@mid", manager.SelectedValue.ToString());
            cmd1.Parameters.AddWithValue("@bid", lbl_bid.Text);
            cmd1.Parameters.AddWithValue("@status", status);
            int i = cmd1.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Updated!!')</script>");
                Response.Redirect("BranchManagement.aspx");
            }
            else
            {
                Response.Write("<script>alert('Something went wrong!!')</script>");

            }
            conn.Close();
        }
        catch (Exception e4)
        {
            Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
      //    Response.Redirect("BranchManagement.aspx");
        }
        ClearData1();
        BranchGridView();
    }

    protected void btn_delete_clicked(object sender, EventArgs e)
    {
        conn.Open();
        int status = 1;
        String q = "update tblBranch set status=@status where BranchID=@bid ";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        cmd1.Parameters.AddWithValue("@bid", lbl_bid.Text);
        int i = cmd1.ExecuteNonQuery();
        if (i == 1)
        {
            Response.Write("<script>alert('Deleted!!')</script>");
            Response.Redirect("BranchManagement.aspx");
        }
        else
        {
            Response.Write("<script>alert('Branch Not deleted!!')</script>");
        }
        conn.Close();
        ClearData1();
        BranchGridView();
    }

    private void BranchGridView()
    {
        
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Open();
        String q = "select * from tblBranch where status=@status";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void BindData(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        lbl_bid.Text = gr.Cells[1].Text;
        txt_bname.Text = gr.Cells[2].Text;
        txt_cno.Text = gr.Cells[3].Text;
        txt_place.Value = gr.Cells[4].Text;

        String cid = gr.Cells[5].Text;
        conn.Open();
        String q = "select c.CityName,s.StateName,co.CountryName from tblCity c,tblState s,tblCountry co where c.StateID = s.StateID and s.CountryID = co.CountryID and c.CityID=@cid";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@cid", cid);
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        txt_ci.Text = reader["CityName"].ToString();
        txt_st.Text = reader["StateName"].ToString();
        txt_co.Text = reader["CountryName"].ToString();
        conn.Close();

        manager.SelectedValue = gr.Cells[6].Text;
        ViewManagerUpdate();
        txt_bname.Enabled = true;
        txt_cno.Enabled = true;
        manager.Enabled = true;
        btn_update.Enabled = true;
        btn_delete.Enabled = true;
        btn_set.Enabled = true;
    }

    protected void ViewManager(object sender, EventArgs e)
    {
        ViewManager();
    }

    protected void ViewManagerUpdate(object sender, EventArgs e)
    {
        ViewManagerUpdate();
    }

    private void ViewManager()
    {
        conn.Open();
        int status = 0;
        String q = "select ManagerName,MobileNo,AdharCardNo,Address,EmailAddress from tblManager where ManagerID=@mid and status=@status";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@mid", drop_manager.SelectedValue.ToString());
        cmd.Parameters.AddWithValue("@status", status);
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        lbl_managerName.Text = reader["ManagerName"].ToString();
        lbl_mobileNo.Text = reader["MobileNo"].ToString();
        lbl_adhar.Text = reader["AdharCardNo"].ToString();
        lbl_address.Text = reader["Address"].ToString();
        lbl_email.Text = reader["EmailAddress"].ToString();
        conn.Close();
    }

    private void ViewManagerUpdate()
    {
        conn.Open();
        String q = "select ManagerName,MobileNo,AdharCardNo,Address,EmailAddress from tblManager where ManagerID=@mid";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@mid", manager.SelectedValue.ToString());
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        mname.Text = reader["ManagerName"].ToString();
        mno.Text = reader["MobileNo"].ToString();
        adhar.Text = reader["AdharCardNo"].ToString();
        address.Text = reader["Address"].ToString();
        email.Text = reader["EmailAddress"].ToString();
        conn.Close();
    }

    protected void drop_country_TextChanged(object sender, EventArgs e)
    {
        drop_state.Items.Clear();
        drop_city.Items.Clear();
        drop_state.Items.Add("Select State :-");
        String q = "select s.StateName from tblState s,tblCountry c where c.CountryID = s.CountryID and c.CountryName='" + drop_country.Text + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(q, conn);
        
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            drop_state.Items.Add(reader["StateName"].ToString());
        }
        conn.Close();
    }
}
