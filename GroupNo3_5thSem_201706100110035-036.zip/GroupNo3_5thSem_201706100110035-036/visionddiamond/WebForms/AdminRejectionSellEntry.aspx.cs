﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

public partial class WebForms_AdminRejectionSellEntry : System.Web.UI.Page
{
    String ID, OP, InvoiceNo, Weight;
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);

        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }

            try
            {
                ID = Request.QueryString["RID"];
                OP = Request.QueryString["OP"];

                if (ID == null || OP == null)
                {
                    Response.Redirect("AdminSelling.aspx");
                }
                
            }
            catch (Exception ex)
            {
                Response.Redirect("AdminSelling.aspx");
            }

            conn.Open();
            String q = "select RejectionWeight,Status from tblRejection where RejectionID=@RejectionID";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@RejectionID", ID);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            lbl_RejectionID.Text = ID;
            lbl_RejectionWeight.Text = reader["RejectionWeight"].ToString();
            String DStatus = reader["Status"].ToString();
            conn.Close();
            
            if (DStatus.Equals("2"))
            {
                lbl_SoldWeight.Text = "00";
                txt_AvailableWeight.Text = (Convert.ToDouble(lbl_RejectionWeight.Text) - Convert.ToDouble(lbl_SoldWeight.Text)).ToString();
            }
            else if (DStatus.Equals("3"))
            {
                int flag = 0;
                conn.Open();
                q = "select s.InvoiceNo,s.Weight from tblSales s,tblSalesInvoice si where s.InvoiceNo=si.InvoiceNo and si.Mode=@Mode and s.ModeID=@ModeID";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@Mode", "4");
                cmd.Parameters.AddWithValue("@ModeID", ID);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    flag = 1;
                    InvoiceNo = reader["InvoiceNo"].ToString();
                    Weight = (Convert.ToDouble(Weight) + Convert.ToDouble(reader["Weight"].ToString())).ToString();
                }
                conn.Close();

                if (flag == 1)
                {
                    lbl_SoldWeight.Text = Weight;
                }
                else
                {
                    lbl_SoldWeight.Text = "00";
                }
                txt_AvailableWeight.Text = (Convert.ToDouble(lbl_RejectionWeight.Text) - Convert.ToDouble(lbl_SoldWeight.Text)).ToString();
            }
            else
            {
                txt_AvailableWeight.Text = "00";
            }

            if (!Page.IsPostBack)
            {
                txt_InvoiceNo.Enabled = false;
                conn.Open();
                q = "select InvoiceValue from tblInvoiceIncrement";
                cmd = new SqlCommand(q, conn);
                reader = cmd.ExecuteReader();
                reader.Read();
                txt_InvoiceNo.Text = "VD" + reader["InvoiceValue"].ToString();
                conn.Close();

                q = "select BuyerSellerID,CompanyName from tblBuyerSeller where status='0'";
                conn.Open();
                cmd = new SqlCommand(q, conn);
                drop_BuyerName.DataValueField = "BuyerSellerID";
                drop_BuyerName.DataTextField = "CompanyName";
                drop_BuyerName.DataSource = cmd.ExecuteReader();
                drop_BuyerName.DataBind();
                conn.Close();
            }

            drop_BuyerChanged(sender, e);
        }
    }

    protected void txt_dayTerm_Changed(object sender, EventArgs e)
    {
        try
        {
            if (!txt_SellingDate.Text.Equals("") && !txt_DayTerm.Text.Equals(""))
            {
                DateTime date = DateTime.ParseExact(txt_SellingDate.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                date = date.AddDays(Convert.ToInt32(txt_DayTerm.Text));
                txt_DueDate.Text = date.ToString();
            }
            else
            {
                txt_DueDate.Text = "";
            }
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void drop_BuyerChanged(object sender, EventArgs e)
    {
        conn.Open();
        String q = "select CompanyName,ContactNo,PanNo,GSTIN,Email from tblBuyerSeller where BuyerSellerID=@sellerID";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@sellerID", drop_BuyerName.SelectedValue);
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        lbl_cName.Text = reader["CompanyName"].ToString();
        lbl_cNo.Text = reader["ContactNo"].ToString();
        lbl_panNO.Text = reader["PanNo"].ToString();
        lbl_gstin.Text = reader["GSTIN"].ToString();
        lbl_email.Text = reader["Email"].ToString();
        conn.Close();
    }

    protected void SalesWeightChanged(object sender, EventArgs e)
    {
        try
        {
            if (Convert.ToDouble(txt_SalesWeight.Text) > Convert.ToDouble(txt_AvailableWeight.Text))
            {
                txt_SalesWeight.Text = "";
            }

            if (!txt_SalesWeight.Text.Equals(""))
            {
                txt_NotToSellWeight.Text = (Convert.ToDouble(txt_AvailableWeight.Text) - Convert.ToDouble(txt_SalesWeight.Text)).ToString();
            }
            else
            {
                txt_NotToSellWeight.Text = txt_AvailableWeight.Text;
            }

            if (!txt_SalesWeight.Text.Equals("") && !txt_SalesRate.Text.Equals(""))
            {
                txt_TotalAmount.Text = (Convert.ToDouble(txt_SalesWeight.Text) * Convert.ToDouble(txt_SalesRate.Text)).ToString();
            }
            else
            {
                txt_TotalAmount.Text = "00";
            }
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void btn_SellClicked(object sender, EventArgs e)
    {
        if (OP.Equals("MakeEntry"))
        {
            String q;
            SqlCommand cmd;
                conn.Open();
                q = "insert into tblSalesInvoice (InvoiceNo,Mode) values (@InvoiceNo,@Mode)";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@InvoiceNo", txt_InvoiceNo.Text);
                cmd.Parameters.AddWithValue("@Mode", "4");
                cmd.ExecuteNonQuery();
                conn.Close();

                conn.Open();
                q = "select InvoiceValue from tblInvoiceIncrement";
                cmd = new SqlCommand(q, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                String inc = reader["InvoiceValue"].ToString();
                conn.Close();

                inc = (Convert.ToInt64(inc) + 1).ToString();

                conn.Open();
                q = "update tblInvoiceIncrement set InvoiceValue=@inc";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@inc", inc);
                cmd.ExecuteNonQuery();
                conn.Close();
            

            conn.Open();
            q = "insert into tblSales (InvoiceNo,ModeID,SellingDate,DayTerm,Weight,Rate,Description,TransportationMode,DateOfSupply,PlaceOfSupply,BuyerSellerID) values (@InvoiceNo,@ModeID,@SellingDate,@DayTerm,@Weight,@Rate,@Description,@TransportationMode,@DateOfSupply,@PlaceOfSupply,@BuyerSellerID)";
            cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@InvoiceNo", txt_InvoiceNo.Text);
            cmd.Parameters.AddWithValue("@ModeID", lbl_RejectionID.Text);
            cmd.Parameters.AddWithValue("@SellingDate", txt_SellingDate.Text);
            cmd.Parameters.AddWithValue("@DayTerm", txt_DayTerm.Text);
            cmd.Parameters.AddWithValue("@Weight", txt_SalesWeight.Text);
            cmd.Parameters.AddWithValue("@Rate", txt_SalesRate.Text);
            cmd.Parameters.AddWithValue("@Description", txt_Description.Value);
            cmd.Parameters.AddWithValue("@TransportationMode", txt_TransportationMode.Text);
            cmd.Parameters.AddWithValue("@DateOfSupply", txt_DateOfSupply.Text);
            cmd.Parameters.AddWithValue("@PlaceOfSupply", txt_PlaceOfSupply.Value);
            cmd.Parameters.AddWithValue("@BuyerSellerID", drop_BuyerName.SelectedValue);
            cmd.ExecuteNonQuery();
            conn.Close();

            if (Convert.ToDouble(txt_NotToSellWeight.Text) == 0)
            {
                conn.Open();
                q = "update tblRejection set Status='4' where RejectionID=@RejectionID";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@RejectionID", lbl_RejectionID.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            else
            {
                conn.Open();
                q = "update tblRejection set Status='3' where RejectionID=@RejectionID";
                cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@RejectionID", lbl_RejectionID.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            Server.Transfer("AdminRejectionSellEntry.aspx?RID=" + lbl_RejectionID.Text + "&OP=MakeEntry");

        }
    }

    protected void btn_BackClicked(object sender, EventArgs e)
    {
        Response.Redirect("AdminSelling.aspx");
    }
}