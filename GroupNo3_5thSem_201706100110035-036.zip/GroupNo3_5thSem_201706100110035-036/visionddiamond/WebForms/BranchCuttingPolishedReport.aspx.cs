﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_BranchCuttingPolishedReport : System.Web.UI.Page
{
    SqlConnection conn;
    String lid, username, password, bid, AID, OP, PID;
    protected void Page_Load(object sender, EventArgs e)
    {

        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            
            lid = Session["Lid"].ToString();
            username = Session["Username"].ToString();
            password = Session["Password"].ToString();
            bid = Session["BID"].ToString();
            AID = Request.QueryString["AID"];
            OP = Request.QueryString["OP"];
            if (lid == null || username == null || password == null || bid == null)
            {
                Response.Redirect("Login.aspx?message=1");
            }

         
        }
        
        
        
    }

    protected void btn_findClicked(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select a.AllocationID,a.AllocationDate,c.Weight,c.MakableWeight,pd.PolishedWeight,pd.PolishedQuantity,pd.ReturnDate from tblPurchaseAllocation a,tblPolished pd,tblCutting c,tblPurchaseDetails p where c.AllocationID=pd.AllocationID and a.AllocationID=c.AllocationID and p.PurchaseID=a.PurchaseID and (p.DiamondStatus='0' or p.DiamondStatus>=@DiamondStatus) and p.Status=@Status and a.BranchID=@BranchID and pd.ReturnDate between @startDate and @endDate";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@DiamondStatus","4");
        cmd1.Parameters.AddWithValue("@Status","0");
        cmd1.Parameters.AddWithValue("@BranchID",bid);
        cmd1.Parameters.AddWithValue("@startDate", txt_startDate.Text);
        cmd1.Parameters.AddWithValue("@endDate", txt_lastDate.Text);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();

    }
    protected void btn_sevendays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select a.AllocationID,a.AllocationDate,c.Weight,c.MakableWeight,pd.PolishedWeight,pd.PolishedQuantity,pd.ReturnDate from tblPurchaseAllocation a,tblPolished pd,tblCutting c,tblPurchaseDetails p where c.AllocationID=pd.AllocationID and a.AllocationID=c.AllocationID and p.PurchaseID=a.PurchaseID and (p.DiamondStatus='0' or p.DiamondStatus>=@DiamondStatus) and p.Status=@Status and a.BranchID=@BranchID and pd.ReturnDate >= DATEADD(DAY, -7,GETDATE()) and pd.ReturnDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@DiamondStatus", "4");
        cmd1.Parameters.AddWithValue("@Status", "0");
        cmd1.Parameters.AddWithValue("@BranchID", bid);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_thirtyDays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select a.AllocationID,a.AllocationDate,c.Weight,c.MakableWeight,pd.PolishedWeight,pd.PolishedQuantity,pd.ReturnDate from tblPurchaseAllocation a,tblPolished pd,tblCutting c,tblPurchaseDetails p where c.AllocationID=pd.AllocationID and a.AllocationID=c.AllocationID and p.PurchaseID=a.PurchaseID and (p.DiamondStatus='0' or p.DiamondStatus>=@DiamondStatus) and p.Status=@Status and a.BranchID=@BranchID and pd.ReturnDate >= DATEADD(MONTH, -1,GETDATE()) and pd.ReturnDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@DiamondStatus", "4");
        cmd1.Parameters.AddWithValue("@Status", "0");
        cmd1.Parameters.AddWithValue("@BranchID", bid);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_nintyDays(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select a.AllocationID,a.AllocationDate,c.Weight,c.MakableWeight,pd.PolishedWeight,pd.PolishedQuantity,pd.ReturnDate from tblPurchaseAllocation a,tblPolished pd,tblCutting c,tblPurchaseDetails p where c.AllocationID=pd.AllocationID and a.AllocationID=c.AllocationID and p.PurchaseID=a.PurchaseID and (p.DiamondStatus='0' or p.DiamondStatus>=@DiamondStatus) and p.Status=@Status and a.BranchID=@BranchID and pd.ReturnDate >= DATEADD(MONTH, -3,GETDATE()) and pd.ReturnDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@DiamondStatus", "4");
        cmd1.Parameters.AddWithValue("@Status", "0");
        cmd1.Parameters.AddWithValue("@BranchID", bid);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_oneYear(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select a.AllocationID,a.AllocationDate,c.Weight,c.MakableWeight,pd.PolishedWeight,pd.PolishedQuantity,pd.ReturnDate from tblPurchaseAllocation a,tblPolished pd,tblCutting c,tblPurchaseDetails p where c.AllocationID=pd.AllocationID and a.AllocationID=c.AllocationID and p.PurchaseID=a.PurchaseID and (p.DiamondStatus='0' or p.DiamondStatus>=@DiamondStatus) and p.Status=@Status and a.BranchID=@BranchID and pd.ReturnDate >= DATEADD(YEAR, -1,GETDATE()) and pd.ReturnDate <= (GETDATE())";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@DiamondStatus", "4");
        cmd1.Parameters.AddWithValue("@Status", "0");
        cmd1.Parameters.AddWithValue("@BranchID", bid);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void btn_allTime(object sender, EventArgs e)
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        conn.Close();
        conn.Open();
        String q = "select a.AllocationID,a.AllocationDate,c.Weight,c.MakableWeight,pd.PolishedWeight,pd.PolishedQuantity,pd.ReturnDate from tblPurchaseAllocation a,tblPolished pd,tblCutting c,tblPurchaseDetails p where c.AllocationID=pd.AllocationID and a.AllocationID=c.AllocationID and p.PurchaseID=a.PurchaseID and (p.DiamondStatus='0' or p.DiamondStatus>=@DiamondStatus) and p.Status=@Status and a.BranchID=@BranchID";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@DiamondStatus", "4");
        cmd1.Parameters.AddWithValue("@Status", "0");
        cmd1.Parameters.AddWithValue("@BranchID", bid);
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
    }

    protected void FullDescription(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        Server.Transfer("BranchCuttingPolishedCompleteReport.aspx?aid=" + gr.Cells[1].Text);
    }
}