﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

    public partial class WebForms_Login : System.Web.UI.Page
    {
        SqlConnection conn;
        protected void Page_Load(object sender, EventArgs e)
        {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (!Session.IsNewSession)
            {
                Session.Abandon();
            }

            if (Request.QueryString["message"] != null)
            {
                if (Request.QueryString["message"].ToString().Equals("1"))
                {
                    ErrorMessage.Text = "Please Login First !!!!";
                }
                else if (Request.QueryString["message"].ToString().Equals("2"))
                {
                    ErrorMessage.Text = "Successfully Logout";
                }
            }
        }

    protected void submitClick(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            String username = uname.Text;
            String password = passwd.Text;

            if (username.Equals("admin") && password.Equals("admin"))
            {
                Session["username"] = username;
                Session["password"] = password;
                Response.Redirect("AdminDashboard.aspx");
            }
            else
            {
                int status = 0;
                String q = "select * from Login where Username='" + username + "' and Password='" + password + "' and status=@status";
                conn.Open();
                SqlCommand cmd = new SqlCommand(q, conn);
                cmd.Parameters.AddWithValue("@status", status);
                SqlDataReader reader = cmd.ExecuteReader();
                int flag = 0;
                String lid = null, bid = null,bname = null,bpasswd = null;
                while (reader.Read())
                {
                    flag = 1;
                    lid = reader["Lid"].ToString();
                    bname = reader["Username"].ToString();
                    bpasswd = reader["Password"].ToString();
                    bid = reader["Branch_ID"].ToString();
                }
                conn.Close();
                if (flag == 0)
                {
                    ErrorMessage.Text = "Invalid User !!!";
                }
                else if(flag == 1)
                {
                    Session["Lid"] = lid;
                    Session["Username"] = bname;
                    Session["Password"] = bpasswd;
                    Session["BID"] = bid;
                    Response.Redirect("BranchDashboard.aspx");
                }
                
                
            }
        }
        else
        {
            ErrorMessage.Text = "All Fields Are Required !!";
        }
    }

    protected void btn_Home_Clicked(object sender, EventArgs e)
    {
        Response.Redirect("~/Home.aspx");
    }
}

