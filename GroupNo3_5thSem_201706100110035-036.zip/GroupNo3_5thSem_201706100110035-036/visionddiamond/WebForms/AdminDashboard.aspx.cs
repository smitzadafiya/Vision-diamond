﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

using System.Web.UI.DataVisualization.Charting;

public partial class WebForms_AdminDashboard : System.Web.UI.Page
{
    String date, desc,rid;
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn=new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }
            //            SELECT DATENAME(Month, OrderDate) AS Month, COUNT(OrderId) as TotalOrders  FROM Orders WHERE OrderDate BETWEEN '1996-01-01' AND '1996-12-31' GROUP BY DATENAME(Month, OrderDate)"
            string q = "select DATENAME(Month, PurchaseDate) AS Month , sum(Weight) AS TotalPurchase   from tblPurchaseDetails where PurchaseDate >= DATEADD(MONTH,-6,GETDATE())  group by  DATENAME(Month,PurchaseDate)";
            conn.Open();
            SqlCommand cmd = new SqlCommand(q, conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            conn.Close();

            String[] x = new string[dt.Rows.Count];
            double[] y = new double[dt.Rows.Count];



            for (int i = 0; i < dt.Rows.Count; i++)
            {

                x[i] = dt.Rows[i][0].ToString();
                y[i] = Convert.ToDouble(dt.Rows[i][1]);

            }
            Chart1.Series[0].Points.DataBindXY(x, y);
            Chart1.Series[0].ChartType = SeriesChartType.Pie;



            selling();

            conn.Open();
            string q1 = "select rid,date,description from tblReminder where status='0'";
            
            
            SqlCommand cmd2 = new SqlCommand(q1, conn);
            SqlDataReader rd = cmd2.ExecuteReader();
            while (rd.Read()){
                rid = rd["rid"].ToString();
                date = rd["date"].ToString();
                desc = rd["description"].ToString();
            }
            conn.Close();
            Label1.Text = date +" " + desc;
        }
    }

    public void selling()
    {
        string q1 = "select DATENAME(Month,SellingDate) AS Month , sum(Weight) AS TotalSelling   from tblSales where SellingDate >= DATEADD(MONTH,-6,GETDATE())  group by  DATENAME(Month,SellingDate)";
        conn.Open();
        SqlCommand cmd1 = new SqlCommand(q1, conn);
        SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
        DataTable dt1 = new DataTable();
        da1.Fill(dt1);
        conn.Close();

        String[] x = new string[dt1.Rows.Count];
        double[] y = new double[dt1.Rows.Count];



        for (int i = 0; i < dt1.Rows.Count; i++)
        {

            x[i] = dt1.Rows[i][0].ToString();
            y[i] = Convert.ToDouble(dt1.Rows[i][1]);

        }
        Chart2.Series[0].Points.DataBindXY(x, y);
        Chart2.Series[0].ChartType = SeriesChartType.Area;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        conn.Open();
        string q3 = "update tblReminder set status='1' where rid='"+rid+"'";
        SqlCommand cmd = new SqlCommand(q3, conn);
        cmd.ExecuteNonQuery();
        conn.Close();
    } 
}