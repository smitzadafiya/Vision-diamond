﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Configuration;
using iTextSharp.tool.xml;

public partial class WebForms_PurchaseFullDescription : System.Web.UI.Page
{
    SqlConnection conn;
    String pid;
    string sname;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            Panel1.Visible = true;
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }

            pid = Request.QueryString["pid"];
            if (pid == null)
            {
                Response.Redirect("SearchPurchaseRecoard.aspx");
            }
            else
            {
                try
                {
                    conn.Open();
                    String q = "select InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount,BuyerSellerID,BrokerID,DiamondStatus from tblPurchaseDetails where PurchaseID=@purchaseID";
                    SqlCommand cmd = new SqlCommand(q,conn);
                    cmd.Parameters.AddWithValue("purchaseID",pid);
                    SqlDataReader reader = cmd.ExecuteReader();
                    reader.Read();
                        lbl_invoiceNo.Text = reader["InvoiceNo"].ToString();
                        lbl_PurchaseDate.Text = reader["PurchaseDate"].ToString();
                        lbl_DayTerm.Text = reader["DayTerm"].ToString();
                        lbl_description.Text = reader["Description"].ToString();

                    if (reader["DiamondType"].ToString().Equals("P"))
                    {
                        lbl_DiamondType.Text = "Polished";
                    }
                    else
                    {
                        lbl_DiamondType.Text = "Rough";
                    }
                        lbl_Weight.Text = reader["Weight"].ToString();
                        lbl_Amount.Text = reader["Amount"].ToString();
                        lbl_TotalAmount.Text = (Convert.ToDouble(reader["Weight"].ToString()) * Convert.ToDouble(reader["Amount"].ToString())).ToString();
                        String BSID = reader["BuyerSellerID"].ToString();
                        String BRID = reader["BrokerID"].ToString();
                        String DStatus = reader["DiamondStatus"].ToString();
                    conn.Close();

                    conn.Open();
                    q = "select bs.CompanyName,bs.ContactNo,bs.PanNo,bs.GSTIN,bs.Address,bs.Email,c.CityName,s.StateName,co.CountryName from tblBuyerSeller bs,tblCity c,tblState s, tblCountry co where bs.BuyerSellerID=@BSID and c.CityID = bs.CityID and s.StateID = c.StateID and co.CountryID = s.CountryID";
                    cmd = new SqlCommand(q,conn);
                    cmd.Parameters.AddWithValue("@BSID",BSID);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                    sname = reader["CompanyName"].ToString();
                    lbl_BSCompanyName.Text = sname;
                    lbl_BSMobileNo.Text = reader["ContactNo"].ToString();
                    lbl_BSPanNo.Text = reader["PanNo"].ToString();
                    lbl_BSGSTIN.Text = reader["GSTIN"].ToString();
                    lbl_BSEmail.Text = reader["Email"].ToString();
                    lbl_BSAddress.Text = reader["Address"].ToString();
                    lbl_BSCity.Text = reader["CityName"].ToString();
                    lbl_BSState.Text = reader["StateName"].ToString();
                    lbl_BSCountry.Text = reader["CountryName"].ToString();
                    conn.Close();

                    if (BRID.Equals("0"))
                    {
                        lbl_BrokerName.Text = "-";
                        lbl_BRMobileNo.Text = "-";
                        lbl_BREmail.Text = "-";
                    }
                    else
                    {
                        conn.Open();
                        q = "select BrokerName,MobileNo,Email from tblBroker where BrokerID=@BRID";
                        cmd = new SqlCommand(q,conn);
                        cmd.Parameters.AddWithValue("@BRID",BRID);
                        reader = cmd.ExecuteReader();
                        reader.Read();
                        lbl_BrokerName.Text = reader["BrokerName"].ToString();
                        lbl_BRMobileNo.Text = reader["MobileNo"].ToString();
                        lbl_BREmail.Text = reader["Email"].ToString();
                        conn.Close();
                    }

                    if (DStatus.Equals("1") || DStatus.Equals("8") || DStatus.Equals("9") || DStatus.Equals("6"))
                    {
                        lbl_BranchName.Text = "-";
                        lbl_BranchContactNo.Text = "-";
                        lbl_BranchManagerName.Text = "-";
                        lbl_AllocationDate.Text = "-";
                        lbl_DiamondStatus.Text = "Purchased";
                    }
                    else
                    {
                        int flag = 0;
                        conn.Open();
                        q = "select br.BranchName,br.ContactNo,m.ManagerName,a.AllocationDate from tblBranch br,tblManager m,tblPurchaseAllocation a where a.PurchaseID=@purchaseID and br.BranchID=a.BranchID and m.ManagerID=br.ManagerID";
                        cmd = new SqlCommand(q,conn);
                        cmd.Parameters.AddWithValue("purchaseID",pid);
                        reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            lbl_BranchName.Text = reader["BranchName"].ToString();
                            lbl_BranchContactNo.Text = reader["ContactNo"].ToString();
                            lbl_BranchManagerName.Text = reader["ManagerName"].ToString();
                            lbl_AllocationDate.Text = reader["AllocationDate"].ToString();
                        }
                        
                        conn.Close();

                        if (DStatus.Equals("1"))
                        {
                            lbl_DiamondStatus.Text = "Currently Purchased";
                        }
                        else if (DStatus.Equals("2"))
                        {
                            lbl_DiamondStatus.Text = "In Cutting Process";
                        }
                        else if (DStatus.Equals("3"))
                        {
                            lbl_DiamondStatus.Text = "In Polished Process";
                        }
                        else if (DStatus.Equals("4"))
                        {
                            lbl_DiamondStatus.Text = "Polished COmpleted";
                        }
                        else if (DStatus.Equals("5"))
                        {
                            lbl_DiamondStatus.Text = "Now For Salling";
                        }
                        else if (DStatus.Equals("6"))
                        {
                            lbl_DiamondStatus.Text = "Half Rough Sold";
                        }
                        else if (DStatus.Equals("7"))
                        {
                            lbl_DiamondStatus.Text = "Half Polished Sold";
                        }
                        else if (DStatus.Equals("8"))
                        {
                            lbl_DiamondStatus.Text = "Now For Sell";
                        }
                        else if (DStatus.Equals("9"))
                        {
                            lbl_DiamondStatus.Text = "Half Sold";
                        }
                        else if (DStatus.Equals("0"))
                        {
                            lbl_DiamondStatus.Text = "Sold";
                        }

                    }
                }
                catch (Exception ex)
                {
                    Response.Write(ex);
                }
            }
        }
    }

    protected void btn_BackClicked(object sender, EventArgs e)
    {
        Response.Redirect("SearchPurchaseRecoard.aspx");
    }

    protected void btn_downloadClicked(object sender, EventArgs e)
    {
        exportpdf();
    }
    private void exportpdf()
    {
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename='"+sname+"'.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            Panel1.RenderControl(hw);
            StringReader sr = new StringReader(sw.ToString());
            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            htmlparser.Parse(sr);
            pdfDoc.Close();
            Response.Write(pdfDoc);
            Response.End();
     }
        
    }
    
