﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class WebForms_Reminderbranch : System.Web.UI.Page
{
    SqlConnection conn;

    String lid, username, password, bid, AID;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            lid = Session["Lid"].ToString();
            username = Session["Username"].ToString();
            password = Session["Password"].ToString();
            bid = Session["BID"].ToString();
            AID = Request.QueryString["AID"];
            if (lid == null || username == null || password == null || bid == null)
            {
                Response.Redirect("Login.aspx?message=1");
            }
        }



    }
    protected void set_reminder(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            int status = 0;
            SqlCommand cmd = new SqlCommand("insert into tblReminder(date,description,branchid,status) values(@date,@description,@branchid,@status)", conn);
            cmd.Parameters.AddWithValue("@date", date.Text);
            cmd.Parameters.AddWithValue("@description", description.Value);
            cmd.Parameters.AddWithValue("@branchid", bid);
            cmd.Parameters.AddWithValue("@status", status);
            int a = cmd.ExecuteNonQuery();

            if (a == 1)
            {
                Response.Write("<script>alert('Set!!')</script>");
                //Response.Redirect("BranchManagement.aspx");
            }
            else
            {
                Response.Write("<script>alert('Something Went Wrong!!')</script>");
            }
            conn.Close();
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Something Went Wrong !! Please try again.. ')</script>");
        }
    }
}