﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Globalization;
using System.Configuration;

public partial class WebForms_PurchaseDetails : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);

        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }

            if (!Page.IsPostBack)
            {
                String q = "select BuyerSellerID,CompanyName from tblBuyerSeller where status='0'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(q, conn);
                drop_seller.DataValueField = "BuyerSellerID";
                drop_seller.DataTextField = "CompanyName";
                drop_seller.DataSource = cmd.ExecuteReader();
                drop_seller.DataBind();
                conn.Close();
                conn.Open();
                sellerCompany.DataValueField = "BuyerSellerID";
                sellerCompany.DataTextField = "CompanyName";
                sellerCompany.DataSource = cmd.ExecuteReader();
                sellerCompany.DataBind();
                conn.Close();

                q = "select BrokerID,BrokerName from tblBroker where status='0'";
                conn.Open();
                cmd = new SqlCommand(q, conn);
                drop_broker.DataValueField = "BrokerID";
                drop_broker.DataTextField = "BrokerName";
                drop_broker.DataSource = cmd.ExecuteReader();
                drop_broker.DataBind();
                conn.Close();
                conn.Open();
                broker.DataValueField = "BrokerID";
                broker.DataTextField = "BrokerName";
                broker.DataSource = cmd.ExecuteReader();
                broker.DataBind();
                conn.Close();

                chk_broker.Checked = false;
                drop_broker.Enabled = false;

                SellerChanged(sender,e);
                drop_SellerChanged(sender, e);
            }
            BranchGridView();
        }
    }

    protected void btn_add_clicked(object sender, EventArgs e)
    {
        try { 
        conn.Open();
        String q;
        if (chk_broker.Checked)
        {
            q = "insert into tblPurchaseDetails (InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount,BuyerSellerID,BrokerID,DiamondStatus,Status) values (@InvoiceNo,@PurchaseDate,@DayTerm,@Description,@DiamondType,@Weight,@Amount,@BuyerSellerID,@BrokerID,@DiamondStatus,@Status)";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@InvoiceNo", txt_invoiceNo.Text);
            cmd.Parameters.AddWithValue("@PurchaseDate", txt_date.Text);
            cmd.Parameters.AddWithValue("@DayTerm", txt_dayTerm.Text);
            cmd.Parameters.AddWithValue("@Description", txt_description.Value);
            String temp;
            if (drop_Type.Text.Equals("Rough"))
            {
                temp = "R";
            }
            else
            {
                temp = "P";
            }
            cmd.Parameters.AddWithValue("@DiamondType", temp);
            cmd.Parameters.AddWithValue("@Weight", txt_weight.Text);
            cmd.Parameters.AddWithValue("@Amount", txt_amount.Text);
            cmd.Parameters.AddWithValue("@BuyerSellerID", drop_seller.SelectedValue);
            cmd.Parameters.AddWithValue("@BrokerID", drop_broker.SelectedValue);
            if (drop_Type.Text.Equals("Rough"))
            {
                cmd.Parameters.AddWithValue("@DiamondStatus", "1");
            }
            else
            {
                cmd.Parameters.AddWithValue("@DiamondStatus", "8");
            }
            cmd.Parameters.AddWithValue("@Status", "0");
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('New Purchase Successfully Registered...')</script>");
                Response.Redirect("PurchaseDetails.aspx");
            }
            else
            {
                Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
            }
        }
        else
        {
            q = "insert into tblPurchaseDetails (InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount,BuyerSellerID,BrokerID,DiamondStatus,Status) values (@InvoiceNo,@PurchaseDate,@DayTerm,@Description,@DiamondType,@Weight,@Amount,@BuyerSellerID,@BrokerID,@DiamondStatus,@Status)";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@InvoiceNo", txt_invoiceNo.Text);
            cmd.Parameters.AddWithValue("@PurchaseDate", txt_date.Text);
            cmd.Parameters.AddWithValue("@DayTerm", txt_dayTerm.Text);
            cmd.Parameters.AddWithValue("@Description", txt_description.Value);
            String temp;
            if (drop_Type.Text.Equals("Rough"))
            {
                temp = "R";
            }
            else
            {
                temp = "P";
            }
            cmd.Parameters.AddWithValue("@DiamondType", temp);
            cmd.Parameters.AddWithValue("@Weight", txt_weight.Text);
            cmd.Parameters.AddWithValue("@Amount", txt_amount.Text);
            cmd.Parameters.AddWithValue("@BuyerSellerID", drop_seller.SelectedValue);
            cmd.Parameters.AddWithValue("@BrokerID", "0");
                if (drop_Type.Text.Equals("Rough"))
                {
                    cmd.Parameters.AddWithValue("@DiamondStatus", "1");
                }
                else
                {
                    cmd.Parameters.AddWithValue("@DiamondStatus", "8");
                }
                cmd.Parameters.AddWithValue("@Status", "0");
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('New Purchase Successfully Registered...')</script>");
                Response.Redirect("PurchaseDetails.aspx");
            }
            else
            {
                Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
            }
        }
        conn.Close();
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }
    protected void drop_SellerChanged(object sender, EventArgs e)
    {
        conn.Open();
        String q = "select CompanyName,ContactNo,PanNo,GSTIN,Email from tblBuyerSeller where BuyerSellerID=@sellerID";
        SqlCommand cmd = new SqlCommand(q,conn);
        cmd.Parameters.AddWithValue("@sellerID",drop_seller.SelectedValue);
        SqlDataReader reader =  cmd.ExecuteReader();
        reader.Read();
        lbl_cName.Text = reader["CompanyName"].ToString();
        lbl_cNo.Text = reader["ContactNo"].ToString();
        lbl_panNO.Text = reader["PanNo"].ToString();
        lbl_gstin.Text = reader["GSTIN"].ToString();
        lbl_email.Text = reader["Email"].ToString();
        conn.Close();
    }

    protected void SellerChanged(object sender, EventArgs e)
    {
        conn.Open();
        String q = "select CompanyName,ContactNo,PanNo,GSTIN,Email from tblBuyerSeller where BuyerSellerID=@sellerID";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.AddWithValue("@sellerID", sellerCompany.SelectedValue);
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        cName.Text = reader["CompanyName"].ToString();
        cNo.Text = reader["ContactNo"].ToString();
        PanNo.Text = reader["PanNo"].ToString();
        GSTIN.Text = reader["GSTIN"].ToString();
        Email.Text = reader["Email"].ToString();
        conn.Close();
    }

    protected void txt_dayTerm_Changed(object sender, EventArgs e)
    {
        try { 
        if (!txt_date.Text.Equals("") && !txt_dayTerm.Text.Equals(""))
        {
            DateTime date = DateTime.ParseExact(txt_date.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            date = date.AddDays(Convert.ToInt32(txt_dayTerm.Text));
            txt_dueDate.Text = date.ToString();
        }
        else
        {
            txt_dueDate.Text = "";
        }
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void totalAmountChanged(object sender, EventArgs e)
    {
        try
        {
            if (!txt_weight.Text.Equals("") && !txt_amount.Text.Equals(""))
            {
                txt_tAmount.Text = (Convert.ToDouble(txt_weight.Text) * Convert.ToDouble(txt_amount.Text)).ToString() + "Rs.";
            }
            else
            {
                txt_tAmount.Text = "00 Rs.";
            }
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void chk_broker_Changed(object sender, EventArgs e)
    {
        if (chk_broker.Checked)
        {
            drop_broker.Enabled = true;
        }
        else
        {
            drop_broker.Enabled = false;
        }
    }

    protected void chkBroker_Changed(object sender, EventArgs e)
    {
        if (chkBroker.Checked)
        {
            broker.Enabled = true;
        }
        else
        {
            broker.Enabled = false;
        }
    }

    private void BranchGridView()
    {
        GridView1.DataSource = null;
        GridView1.DataBind();
        int status = 0;
        conn.Close();
        conn.Open();
        String q = "select PurchaseID,InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount,BuyerSellerID,BrokerID from tblPurchaseDetails where Status=@status and DiamondStatus=@dstatus";
        SqlCommand cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        cmd1.Parameters.AddWithValue("@dstatus", "1");
        GridView1.DataSource = cmd1.ExecuteReader();
        GridView1.DataBind();
        conn.Close();

        GridView2.DataSource = null;
        GridView2.DataBind();
        conn.Close();
        conn.Open();
        q = "select p.PurchaseID,p.InvoiceNo,p.PurchaseDate,p.DayTerm,p.Description,p.DiamondType,p.Weight,p.Amount,p.BuyerSellerID,p.BrokerID from tblPurchaseDetails p,tblPurchaseAllocation a where p.Status=@status and p.DiamondStatus=@dstatus  and p.PurchaseID=a.PurchaseID and a.Status='1'";
        cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", status);
        cmd1.Parameters.AddWithValue("@dstatus", "2");
        GridView2.DataSource = cmd1.ExecuteReader();
        GridView2.DataBind();
        conn.Close();

        GridView3.DataSource = null;
        GridView3.DataBind();
        conn.Open();
        q = "select PurchaseID,InvoiceNo,PurchaseDate,DayTerm,Description,DiamondType,Weight,Amount,BuyerSellerID,BrokerID from tblPurchaseDetails where Status=@status and DiamondStatus=@dstatus and DiamondType=@DiamondType";
        cmd1 = new SqlCommand(q, conn);
        cmd1.Parameters.AddWithValue("@status", "0");
        cmd1.Parameters.AddWithValue("@dstatus", "8");
        cmd1.Parameters.AddWithValue("@DiamondType", "P");
        GridView3.DataSource = cmd1.ExecuteReader();
        GridView3.DataBind();
        conn.Close();
    }

    protected void dayTerm_Changed(object sender, EventArgs e)
    {
        if (!pDate.Text.Equals("") && !dayTerm.Text.Equals(""))
        {
            try
            {
                DateTime date = DateTime.ParseExact(pDate.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                date = date.AddDays(Convert.ToInt32(dayTerm.Text));
                dueDate.Text = date.ToString();
            }
            catch (Exception e1)
            {
                Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
            }
        }
        else
        {
            dueDate.Text = "";
        }
    }

    protected void tAmountChanged(object sender, EventArgs e)
    {
        try { 
        if (!weight.Text.Equals("") && !amount.Text.Equals(""))
        {
            tAmount.Text = (Convert.ToDouble(weight.Text) * Convert.ToDouble(amount.Text)).ToString() + "Rs.";
        }
        else
        {
            tAmount.Text = "00 Rs.";
        }
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }

    protected void BindData(object sender, EventArgs e)
    {
        GridViewRow gr = GridView1.SelectedRow;
        lbl_pid.Text = gr.Cells[1].Text;
        invoiceNo.Text = gr.Cells[2].Text;
        DateTime cdate = DateTime.Parse(gr.Cells[3].Text);
        pDate.Text = cdate.ToString("yyyy-MM-dd");
        dayTerm.Text = gr.Cells[4].Text;
        description.Value = gr.Cells[5].Text;
        dType.SelectedValue = gr.Cells[6].Text;
        if (gr.Cells[6].Text.Equals("R"))
        {
            btn_BranchAllocation.Visible = true;
        }
        else
        {
            btn_BranchAllocation.Visible = false;
        }
        weight.Text = gr.Cells[7].Text;
        amount.Text = gr.Cells[8].Text;
        sellerCompany.SelectedValue = gr.Cells[9].Text;
        if (gr.Cells[10].Text.Equals("0"))
        {
            chkBroker.Checked = false;
            
        }
        else
        {
            chkBroker.Checked = true;
            broker.SelectedValue = gr.Cells[10].Text;
        }
        dayTerm_Changed(sender, e);
        tAmountChanged(sender, e);
        chkBroker_Changed(sender, e);
        SellerChanged(sender,e);
        btn_BranchAllocation.Enabled = true;
    }

    protected void BindData3(object sender, EventArgs e)
    {
        GridViewRow gr = GridView3.SelectedRow;
        lbl_pid.Text = gr.Cells[1].Text;
        invoiceNo.Text = gr.Cells[2].Text;
        DateTime cdate = DateTime.Parse(gr.Cells[3].Text);
        pDate.Text = cdate.ToString("yyyy-MM-dd");
        dayTerm.Text = gr.Cells[4].Text;
        description.Value = gr.Cells[5].Text;
        dType.SelectedValue = gr.Cells[6].Text;
        if (gr.Cells[6].Text.Equals("R"))
        {
            btn_BranchAllocation.Visible = true;
        }
        else
        {
            btn_BranchAllocation.Visible = false;
        }
        weight.Text = gr.Cells[7].Text;
        amount.Text = gr.Cells[8].Text;
        sellerCompany.SelectedValue = gr.Cells[9].Text;
        if (gr.Cells[10].Text.Equals("0"))
        {
            chkBroker.Checked = false;

        }
        else
        {
            chkBroker.Checked = true;
            broker.SelectedValue = gr.Cells[10].Text;
        }
        dayTerm_Changed(sender, e);
        tAmountChanged(sender, e);
        chkBroker_Changed(sender, e);
        SellerChanged(sender, e);
        btn_BranchAllocation.Enabled = true;
    }

    protected void BindData2(object sender, EventArgs e)
    {
        GridViewRow gr = GridView2.SelectedRow;
        lbl_pid.Text = gr.Cells[1].Text;
        invoiceNo.Text = gr.Cells[2].Text;
        DateTime cdate = DateTime.Parse(gr.Cells[3].Text);
        pDate.Text = cdate.ToString("yyyy-MM-dd");
        dayTerm.Text = gr.Cells[4].Text;
        description.Value = gr.Cells[5].Text;
        dType.SelectedValue = gr.Cells[6].Text;
        if (gr.Cells[6].Text.Equals("R"))
        {
            btn_BranchAllocation.Visible = true;
        }
        else
        {
            btn_BranchAllocation.Visible = false;      
        }
        weight.Text = gr.Cells[7].Text;
        amount.Text = gr.Cells[8].Text;
        sellerCompany.SelectedValue = gr.Cells[9].Text;
        if (gr.Cells[10].Text.Equals("0"))
        {
            chkBroker.Checked = false;

        }
        else
        {
            chkBroker.Checked = true;
            broker.SelectedValue = gr.Cells[10].Text;
        }
        dayTerm_Changed(sender, e);
        tAmountChanged(sender, e);
        chkBroker_Changed(sender, e);
        SellerChanged(sender, e);
        btn_BranchAllocation.Enabled = true;
    }

    protected void btn_update_clicked(object sender, EventArgs e)
    {
        try { 
        conn.Open();
        String q;
        if (chkBroker.Checked)
        {
            q = "update tblPurchaseDetails set InvoiceNo=@InvoiceNo,PurchaseDate=@PurchaseDate,DayTerm=@DayTerm,Description=@Description,DiamondType=@DiamondType,Weight=@Weight,Amount=@Amount,BuyerSellerID=@BuyerSellerID,BrokerID=@BrokerID,DiamondStatus=@DiamondStatus where PurchaseID=@PurchaseID";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@InvoiceNo", invoiceNo.Text);
            cmd.Parameters.AddWithValue("@PurchaseDate", pDate.Text);
            cmd.Parameters.AddWithValue("@DayTerm", dayTerm.Text);
                cmd.Parameters.AddWithValue("@Description", description.Value);
            cmd.Parameters.AddWithValue("@DiamondType", dType.SelectedValue);
            cmd.Parameters.AddWithValue("@Weight", weight.Text);
            cmd.Parameters.AddWithValue("@Amount", amount.Text);
            cmd.Parameters.AddWithValue("@BuyerSellerID", sellerCompany.SelectedValue);
            cmd.Parameters.AddWithValue("@BrokerID", broker.SelectedValue);
                if (dType.SelectedValue.Equals("R"))
                {
                    cmd.Parameters.AddWithValue("@DiamondStatus", "1");
                }
                else if (dType.SelectedValue.Equals("P"))
                {
                    cmd.Parameters.AddWithValue("@DiamondStatus", "8");
                }
                cmd.Parameters.AddWithValue("@PurchaseID", lbl_pid.Text);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Purchase Successfully Updated...')</script>");
                Response.Redirect("PurchaseDetails.aspx");
            }
            else
            {
                Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
            }
        }
        else
        {
            q = "update tblPurchaseDetails set InvoiceNo=@InvoiceNo,PurchaseDate=@PurchaseDate,DayTerm=@DayTerm,Description=@Description,DiamondType=@DiamondType,Weight=@Weight,Amount=@Amount,BuyerSellerID=@BuyerSellerID,BrokerID=@BrokerID,DiamondStatus=@DiamondStatus where PurchaseID=@PurchaseID";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@InvoiceNo", invoiceNo.Text);
            cmd.Parameters.AddWithValue("@PurchaseDate", pDate.Text);
            cmd.Parameters.AddWithValue("@DayTerm", dayTerm.Text);
            cmd.Parameters.AddWithValue("@Description", description.Value);
            cmd.Parameters.AddWithValue("@DiamondType", dType.SelectedValue);
            cmd.Parameters.AddWithValue("@Weight", weight.Text);
            cmd.Parameters.AddWithValue("@Amount", amount.Text);
            cmd.Parameters.AddWithValue("@BuyerSellerID", sellerCompany.SelectedValue);
            cmd.Parameters.AddWithValue("@BrokerID", "0");
            if (dType.SelectedValue.Equals("R"))
            {
                cmd.Parameters.AddWithValue("@DiamondStatus", "1");
            }
            else if(dType.SelectedValue.Equals("P"))
            {
                cmd.Parameters.AddWithValue("@DiamondStatus", "8");
            }
            cmd.Parameters.AddWithValue("@PurchaseID", lbl_pid.Text);
            int i = cmd.ExecuteNonQuery();
            if (i == 1)
            {
                Response.Write("<script>alert('Purchase Successfully Updated...')</script>");
                Response.Redirect("PurchaseDetails.aspx");
            }
            else
            {
                Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
            }
        }
        }
        catch (Exception e1)
        {
            Response.Write("<script>alert('Somthing Went Wrong !!')</script>");
        }
    }
    protected void btn_delete_clicked(object sender, EventArgs e)
    {
        conn.Open();
        int status = 1;
        String q = "update tblPurchaseDetails set status=@status where PurchaseID=@pid";
        SqlCommand cmd = new SqlCommand(q, conn);

        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@pid", lbl_pid.Text);

        int i = cmd.ExecuteNonQuery();
        if (i == 1)
        {
            Response.Write("<script>alert('Deleted!!')</script>");
            Response.Redirect("PurchaseDetails.aspx");
        }
        else
        {
            Response.Write("<script>alert('Not Deleted!!')</script>");
        }
        conn.Close();
        BranchGridView();
    }

    protected void BranchAllocation(object sender, EventArgs e)
    {
        Server.Transfer("BranchAllocation.aspx?pid=" + lbl_pid.Text);
    }

    protected void btn_SearchRecordClicked(object sender, EventArgs e)
    {
        Response.Redirect("SearchPurchaseRecoard.aspx");
    }
}