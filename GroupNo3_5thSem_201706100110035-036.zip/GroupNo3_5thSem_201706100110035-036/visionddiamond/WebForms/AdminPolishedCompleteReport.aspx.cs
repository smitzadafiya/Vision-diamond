﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebForms_AdminPolishedCompleteReport : System.Web.UI.Page
{
    SqlConnection conn;
    String AID;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);

        if (Session.IsNewSession)
        {
            Response.Redirect("Login.aspx?message=1");
        }
        else
        {
            String username = Session["username"].ToString();
            String password = Session["password"].ToString();

            if (!username.Equals("admin") && !password.Equals("admin"))
            {
                Response.Redirect("Login.aspx?message=1");
            }

            AID = Request.QueryString["AID"];

            if (AID == null)
            {
                Response.Redirect("AdminCuttingReport.aspx");
            }

            conn.Open();
            String q = "select b.BranchName,b.ContactNo,b.Address,c.CityName,s.StateName,co.CountryName,m.ManagerName,m.MobileNo from tblBranch b,tblCity c,tblState s, tblCountry co, tblManager m, tblPurchaseAllocation a where a.AllocationID=@AID and b.BranchID=a.BranchID and c.CityID = b.CityID and s.StateID = c.StateID and co.CountryID = s.CountryID and m.ManagerID=b.ManagerID";
            SqlCommand cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@AID", AID);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            lbl_BranchName.Text = reader["BranchName"].ToString();
            lbl_ContactNo.Text = reader["ContactNo"].ToString();
            lbl_Address.Text = reader["Address"].ToString();
            lbl_City.Text = reader["CityName"].ToString();
            lbl_State.Text = reader["StateName"].ToString();
            lbl_Country.Text = reader["CountryName"].ToString();
            lbl_ManagerName.Text = reader["ManagerName"].ToString();
            lbl_ManagerMobileNo.Text = reader["MobileNo"].ToString();
            conn.Close();

            conn.Open();
            q = "select p.InvoiceNo,a.Notes,p.Weight,a.AllocationDate,c.MakableWeight,c.RejectionWeight,c.MakableQuantity,c.Rate,c.CompletionDate from tblPurchaseDetails p,tblCutting c,tblPurchaseAllocation a where a.AllocationID=@AID and p.PurchaseID=a.PurchaseID and c.AllocationID=a.AllocationID";
            cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@AID", AID);
            reader = cmd.ExecuteReader();
            reader.Read();
            lbl_PurchaseInvoiceNo.Text = reader["InvoiceNo"].ToString();
            lbl_Notes.Text = reader["Notes"].ToString();
            lbl_RoughWeight.Text = reader["Weight"].ToString();
            lbl_AllocationDate.Text = reader["AllocationDate"].ToString();
            lbl_MakableWeight.Text = reader["MakableWeight"].ToString();
            lbl_RejectionWeight.Text = reader["RejectionWeight"].ToString();
            lbl_CuttingQuantity.Text = reader["MakableQuantity"].ToString();
            lbl_CuttingRate.Text = reader["Rate"].ToString();
            lbl_CompletionDate.Text = reader["CompletionDate"].ToString();
            conn.Close();

            lbl_TotalCuttingAmount.Text = (Convert.ToDouble(lbl_RoughWeight.Text) * Convert.ToDouble(lbl_CuttingRate.Text)).ToString();
            lbl_PolishedAllocationDate.Text = lbl_CompletionDate.Text;

            conn.Open();
            q = "select PolishedWeight,PolishedQuantity,Rate,ReturnDate from tblPolished where AllocationID=@AID";
            cmd = new SqlCommand(q, conn);
            cmd.Parameters.AddWithValue("@AID", AID);
            reader = cmd.ExecuteReader();
            reader.Read();
            lbl_PolishedWeight.Text = reader["PolishedWeight"].ToString();
            lbl_PolishedQuantity.Text = reader["PolishedQuantity"].ToString();
            lbl_PolishedRate.Text = reader["Rate"].ToString();
            lbl_ReturnDate.Text = reader["ReturnDate"].ToString();
            conn.Close();
            lbl_LostWeight.Text = (Convert.ToDouble(lbl_MakableWeight.Text) - Convert.ToDouble(lbl_PolishedWeight.Text)).ToString();
            lbl_LostQuantity.Text = (Convert.ToDouble(lbl_CuttingQuantity.Text) - Convert.ToDouble(lbl_PolishedQuantity.Text)).ToString();
            lbl_PolishedTotalAmount.Text = (Convert.ToDouble(lbl_CuttingQuantity.Text) * Convert.ToDouble(lbl_PolishedRate.Text)).ToString();

            lbl_TotalCharge.Text = (Convert.ToDouble(lbl_PolishedTotalAmount.Text) + Convert.ToDouble(lbl_TotalCuttingAmount.Text)).ToString();
            lbl_WeightPercentage.Text = (Convert.ToInt32((100 * Convert.ToDouble(lbl_PolishedWeight.Text)) / Convert.ToDouble(lbl_RoughWeight.Text))).ToString() + " %";

            lbl_TotalCuttingAmount.Text = lbl_TotalCuttingAmount.Text + " Rs.";
            lbl_PolishedTotalAmount.Text = lbl_PolishedTotalAmount.Text + " Rs.";
            lbl_PolishedRate.Text = lbl_PolishedRate.Text + " Rs.";
            lbl_CuttingRate.Text = lbl_CuttingRate.Text + " Rs.";
            lbl_TotalCharge.Text = lbl_TotalCharge.Text + " Rs.";
        }
    }

    protected void btn_BackClicked(object sender, EventArgs e)
    {
        Response.Redirect("AdminPolishedReport.aspx");
    }
}