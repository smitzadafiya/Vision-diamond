﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class contactus : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        string connection = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        conn = new SqlConnection(connection);
    }

    protected void btn_submit(object sender, EventArgs e)
    {
        int status = 0;

        string q = "insert into tblContactUs (FirstName,LastName,Email,MobileNo,Message,status) values (@FirstName,@LastName,@Email,@MobileNo,@Message,@status) ";
        SqlCommand cmd = new SqlCommand(q, conn);
        cmd.Parameters.Add("@FirstName",firstname.Text);
        cmd.Parameters.Add("@LastName",lastname.Text);
        cmd.Parameters.Add("@Email",email.Text);
        cmd.Parameters.Add("@MobileNo",mobile.Text);
        cmd.Parameters.Add("@Message",message.Value);
        cmd.Parameters.Add("@status",status);

        conn.Open();
        int i = cmd.ExecuteNonQuery();
        if(i==1)
        {
            firstname.Text = null;
            lastname.Text = null;
            email.Text = null;
            mobile.Text = null;
            message.Value = null;
        }
        else
        {
            Response.Write("something went wrong");
        }
        conn.Close();
    }
}