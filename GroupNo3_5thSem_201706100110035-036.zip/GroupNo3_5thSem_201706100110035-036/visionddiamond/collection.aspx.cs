﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class collection : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-Q7NNLFK;Initial Catalog=VisionDiamond;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        int status = 0;
        cn.Open();
        SqlCommand cmd = new SqlCommand("select * from Table_collection where status=@status", cn);
        cmd.Parameters.AddWithValue("@status", status);
        cmd.ExecuteNonQuery();
        DataTable dt = new DataTable();
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        adp.Fill(dt);
        d1.DataSource = dt;
        d1.DataBind();
        cn.Close();
    }
}